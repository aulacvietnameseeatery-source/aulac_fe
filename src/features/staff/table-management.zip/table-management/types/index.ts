export type {
  TableManagementDto,
  TableDetailDto,
  TableMediaDto,
  UpcomingReservationDto,
  CreateTableRequest,
  UpdateTableRequest,
  UpdateTableStatusRequest,
  TableListParams,
  TableFilters,
  TableFormData,
  StatusConfig,
} from "./table.types";

export {
  ALLOWED_TRANSITIONS,
  canTransitionTo,
  TABLE_STATUS_CONFIG,
  TABLE_STATUS_CODES,
  TABLE_ZONE_ICONS,
} from "./table.types";
