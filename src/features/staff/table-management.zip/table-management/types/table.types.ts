// ── Backend DTO — returned by GET /api/tables ──
export interface TableManagementDto {
  tableId: number;
  tableCode: string;
  capacity: number;
  isOnline: boolean;
  statusId: number;
  statusCode: string; // "AVAILABLE" | "OCCUPIED" | "RESERVED" | "LOCKED"
  statusName: string;
  typeId: number;
  typeName: string; // "Regular" | "VIP" | "Booth" | …
  zoneId: number;
  zoneName: string; // "Indoor" | "Outdoor" | "Rooftop"
}

// ── Detail DTO — returned by GET /api/tables/{id} ──
export interface TableDetailDto extends TableManagementDto {
  qrCodeUrl: string | null;
  qrCodeImageUrl: string | null;
  images: TableMediaDto[];
  activeOrdersCount: number;
  hasErrors: boolean;
  upcomingReservations: UpcomingReservationDto[];
}

export interface TableMediaDto {
  mediaId: number;
  url: string;
  isPrimary: boolean;
}

export interface UpcomingReservationDto {
  reservationId: number;
  guestName: string;
  pax: number;
  reservedTime: string; // ISO 8601
  statusCode: string; // "PENDING" | "CONFIRMED"
}

// ── Request bodies ──

export interface CreateTableRequest {
  tableCode: string;
  capacity: number;
  isOnline?: boolean;
  statusLvId: number;
  typeLvId: number;
  zoneLvId: number;
}

export interface UpdateTableRequest {
  tableCode?: string;
  capacity?: number;
  isOnline?: boolean;
  statusLvId?: number;
  typeLvId?: number;
  zoneLvId?: number;
}

export interface UpdateTableStatusRequest {
  statusLvId: number;
}

// ── Query params for list endpoint ──

export interface TableListParams {
  pageIndex?: number;
  pageSize?: number;
  search?: string;
  zoneId?: number;
  typeId?: number;
  statusId?: number;
  isOnline?: boolean;
}

// ── FE filter state (UI layer) ──

export interface TableFilters {
  zone: string; // zoneName or "ALL"
  type: string; // typeName or "ALL"
  status: string; // statusCode or "ALL"
  isOnline: "ALL" | "ONLINE" | "OFFLINE";
  search: string;
}

// ── Status transition rules (mirrors backend) ──

export const ALLOWED_TRANSITIONS: Record<string, string[]> = {
  AVAILABLE: ["OCCUPIED", "RESERVED", "LOCKED"],
  OCCUPIED: ["LOCKED"],
  RESERVED: ["OCCUPIED", "AVAILABLE"],
  LOCKED: ["AVAILABLE"],
};

export function canTransitionTo(current: string, next: string): boolean {
  return ALLOWED_TRANSITIONS[current]?.includes(next) ?? false;
}

// ── Status display config ──

export interface StatusConfig {
  label: string;
  dotColor: string;
  bgColor: string;
  borderColor: string;
  textColor: string;
}

export const TABLE_STATUS_CONFIG: Record<string, StatusConfig> = {
  AVAILABLE: {
    label: "Available",
    dotColor: "bg-emerald-500",
    bgColor: "bg-emerald-50",
    borderColor: "border-emerald-300",
    textColor: "text-emerald-700",
  },
  OCCUPIED: {
    label: "Occupied",
    dotColor: "bg-red-500",
    bgColor: "bg-red-50",
    borderColor: "border-red-300",
    textColor: "text-red-700",
  },
  RESERVED: {
    label: "Reserved",
    dotColor: "bg-amber-500",
    bgColor: "bg-amber-50",
    borderColor: "border-amber-300",
    textColor: "text-amber-700",
  },
  LOCKED: {
    label: "Locked",
    dotColor: "bg-gray-400",
    bgColor: "bg-gray-100",
    borderColor: "border-gray-300",
    textColor: "text-gray-500",
  },
};

export const TABLE_STATUS_CODES = ["AVAILABLE", "OCCUPIED", "RESERVED", "LOCKED"] as const;

// ── Zone display helpers ──

export const TABLE_ZONE_ICONS: Record<string, string> = {
  Indoor: "🏠",
  Outdoor: "🌿",
  Rooftop: "🌤️",
};

// ── Form data for the table modal (FE only) ──

export interface TableFormData {
  tableCode: string;
  capacity: number;
  statusLvId: number | "";
  typeLvId: number | "";
  zoneLvId: number | "";
  isOnline: boolean;
}
