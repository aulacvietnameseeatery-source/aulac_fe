# Table Management — Backend Implementation Guide

> Step-by-step instructions for implementing all required API endpoints.
> Architecture: **ASP.NET Core (.NET 8) — Clean Architecture**
> Last synced with FE: **2026-02-27**

---

## 0. Architecture Context

### Project Structure (Clean Architecture)

```
Solution/
├── Core/                          # Domain layer (innermost)
│   ├── Entities/                  # EF Core entities
│   │   ├── Table.cs
│   │   ├── LookupValue.cs         # Generic lookup (status, type, zone)
│   │   └── Reservation.cs
│   ├── Enum/
│   │   └── NonConfiguableEnums.cs  # ValueCode string constants
│   ├── Interfaces/                # Repository + service contracts
│   │   ├── ITableRepository.cs
│   │   └── ITableService.cs
│   └── DTOs/
│       ├── Table/
│       │   ├── TableManagementDto.cs
│       │   ├── TableDetailDto.cs
│       │   ├── CreateTableRequest.cs
│       │   ├── UpdateTableRequest.cs
│       │   └── UpdateTableStatusRequest.cs
│       └── Common/
│           ├── ApiResponse.cs
│           └── PagedResult.cs
│
├── Infrastructure/                # Data access layer
│   ├── Data/
│   │   └── AppDbContext.cs
│   ├── Repositories/
│   │   └── TableRepository.cs
│   └── Migrations/
│
├── Application/                   # Business logic layer
│   └── Services/
│       └── TableService.cs
│
└── API/                           # Presentation layer (outermost)
    └── Controllers/
        └── TablesController.cs
```

### Existing Conventions (MUST follow)

| Convention | Detail |
|------------|--------|
| **Response envelope** | ALL responses use `ApiResponse<T>` wrapper: `{ success, code, subCode, userMessage, systemMessage, validateInfo, data, serverTime }` |
| **Pagination** | Use `PagedResult<T>`: `{ pageData[], pageIndex, pageSize, totalCount, totalPage }` |
| **Lookup Table pattern** | Statuses, Types, Zones are rows in the `LookupValue` table. Entity FKs are `*LvId` (e.g. `StatusLvId`, `TypeLvId`, `ZoneLvId`). DTOs include both `*Id` and `*Code`/`*Name`. |
| **URL pattern** | `/api/{resource}` (no version prefix). PascalCase query params accepted by ASP.NET model binding. |
| **Auth** | `[Authorize]` attribute. JWT Bearer scheme. Role/permission claims for authorization. |
| **Error response** | Return `ApiResponse` with `success: false`, appropriate `code` (400/404/409/500), `userMessage` for UI display. |

### Lookup Value Codes Relevant to Tables

These MUST exist as seed data in the `LookupValue` table:

```
-- Table Statuses (CategoryCode: "TABLE_STATUS")
AVAILABLE, OCCUPIED, RESERVED, LOCKED

-- Table Types (CategoryCode: "TABLE_TYPE")  
REGULAR, VIP, BOOTH, BAR, HIGH_TOP

-- Table Zones (CategoryCode: "TABLE_ZONE")
INDOOR, OUTDOOR, ROOFTOP

-- Reservation Statuses (CategoryCode: "RESERVATION_STATUS")
PENDING, CONFIRMED, CHECKED_IN, CANCELLED, NO_SHOW
```

> **Note:** The FE also displays `CLEANING` and `OUT_OF_SERVICE` statuses. If these are needed beyond `LOCKED`, add them to the lookup seed. Coordinate with the FE team on which codes to support.

---

## 1. Entity: `Table`

### 1.1 Database Schema

```csharp
public class Table
{
    public int TableId { get; set; }          // PK, auto-increment
    public string TableCode { get; set; }      // Unique, e.g. "T-01"
    public int Capacity { get; set; }          // Number of seats
    public bool IsOnline { get; set; }         // Visible to guests
    
    // Lookup FKs
    public int StatusLvId { get; set; }        // FK → LookupValue
    public int TypeLvId { get; set; }          // FK → LookupValue
    public int ZoneLvId { get; set; }          // FK → LookupValue
    
    // Media
    public string? QrCodeUrl { get; set; }     // Generated QR link
    public string? QrCodeImageUrl { get; set; } // Stored QR image path
    
    // Audit
    public DateTime CreatedAt { get; set; }
    public DateTime? UpdatedAt { get; set; }
    public bool IsDeleted { get; set; }        // Soft delete
    
    // Navigation
    public LookupValue Status { get; set; }
    public LookupValue Type { get; set; }
    public LookupValue Zone { get; set; }
    public ICollection<TableImage> Images { get; set; }
}
```

### 1.2 `TableImage` Entity

```csharp
public class TableImage
{
    public int TableImageId { get; set; }
    public int TableId { get; set; }           // FK → Table
    public string ImageUrl { get; set; }       // CDN/storage path
    public int SortOrder { get; set; }
    public DateTime CreatedAt { get; set; }
    
    public Table Table { get; set; }
}
```

### 1.3 EF Core Configuration

```csharp
// In AppDbContext.OnModelCreating or separate config class
builder.Entity<Table>(e =>
{
    e.HasKey(t => t.TableId);
    e.HasIndex(t => t.TableCode).IsUnique();
    e.HasQueryFilter(t => !t.IsDeleted);  // Global soft delete filter
    
    e.HasOne(t => t.Status).WithMany().HasForeignKey(t => t.StatusLvId);
    e.HasOne(t => t.Type).WithMany().HasForeignKey(t => t.TypeLvId);
    e.HasOne(t => t.Zone).WithMany().HasForeignKey(t => t.ZoneLvId);
    e.HasMany(t => t.Images).WithOne(i => i.Table).HasForeignKey(i => i.TableId);
});
```

---

## 2. DTOs

### 2.1 `TableManagementDto` (list endpoint)

> **CRITICAL:** This DTO already exists and is consumed by the FE. Do NOT change field names.

```csharp
public class TableManagementDto
{
    public int TableId { get; set; }
    public string TableCode { get; set; }
    public int Capacity { get; set; }
    public bool IsOnline { get; set; }
    public int StatusId { get; set; }      // = StatusLvId
    public string StatusCode { get; set; } // = LookupValue.ValueCode
    public string StatusName { get; set; } // = LookupValue display name
    public int TypeId { get; set; }
    public string TypeName { get; set; }
    public int ZoneId { get; set; }
    public string ZoneName { get; set; }
}
```

### 2.2 `TableDetailDto` (detail endpoint — new)

```csharp
public class TableDetailDto : TableManagementDto
{
    public string? QrCodeUrl { get; set; }
    public string? QrCodeImageUrl { get; set; }
    public List<string> Images { get; set; } = new();
    public int ActiveOrdersCount { get; set; }
    public bool HasErrors { get; set; }
    public List<UpcomingReservationDto> UpcomingReservations { get; set; } = new();
}

public class UpcomingReservationDto
{
    public int ReservationId { get; set; }
    public string GuestName { get; set; }
    public int Pax { get; set; }
    public DateTime ReservedTime { get; set; }
    public string StatusCode { get; set; }     // PENDING | CONFIRMED
    public string? PreOrderSummary { get; set; }
}
```

### 2.3 Request DTOs

```csharp
public class CreateTableRequest
{
    [Required, MaxLength(20)]
    public string TableCode { get; set; }
    
    [Range(1, 50)]
    public int Capacity { get; set; }
    
    public bool IsOnline { get; set; } = true;
    
    [Required]
    public int StatusLvId { get; set; }
    
    [Required]
    public int TypeLvId { get; set; }
    
    [Required]
    public int ZoneLvId { get; set; }
}

public class UpdateTableRequest
{
    [MaxLength(20)]
    public string? TableCode { get; set; }
    
    [Range(1, 50)]
    public int? Capacity { get; set; }
    
    public bool? IsOnline { get; set; }
    public int? StatusLvId { get; set; }
    public int? TypeLvId { get; set; }
    public int? ZoneLvId { get; set; }
}

public class UpdateTableStatusRequest
{
    [Required]
    public int StatusLvId { get; set; }
}

public class BulkOnlineRequest
{
    [Required, MinLength(1)]
    public List<int> TableIds { get; set; }
    
    [Required]
    public bool IsOnline { get; set; }
}
```

---

## 3. Controller: `TablesController`

### Implementation Steps

1. Create `Controllers/TablesController.cs`
2. Add `[ApiController]`, `[Route("api/tables")]`, `[Authorize]`
3. Inject `ITableService`
4. Implement each endpoint below

### 3.1 `GET /api/tables` — List Tables (✅ Already exists, verify/enhance)

> **FE call:** `api.get<ApiResponse<PagedResult<TableManagementDto>>>("/api/tables?pageIndex=1&pageSize=100")`

```csharp
[HttpGet]
public async Task<ActionResult<ApiResponse<PagedResult<TableManagementDto>>>> GetTables(
    [FromQuery] int pageIndex = 1,
    [FromQuery] int pageSize = 50,
    [FromQuery] string? search = null,
    [FromQuery] int? zoneLvId = null,
    [FromQuery] int? typeLvId = null,
    [FromQuery] int? statusLvId = null,
    [FromQuery] bool? isOnline = null)
```

**Business logic:**
- Query `Tables` with `.Include(t => t.Status).Include(t => t.Type).Include(t => t.Zone)`
- Apply filters: `search` → `TableCode.Contains(search)` (case-insensitive)
- `zoneLvId` → `ZoneLvId == zoneLvId`, etc.
- `isOnline` → `IsOnline == isOnline`
- Order by `ZoneLvId`, then `TableCode`
- Project to `TableManagementDto` (map `StatusLvId` → `StatusId`, `Status.ValueCode` → `StatusCode`, `Status.DisplayName` → `StatusName`, etc.)
- Paginate with `Skip((pageIndex - 1) * pageSize).Take(pageSize)`
- Return wrapped in `ApiResponse<PagedResult<TableManagementDto>>`

### 3.2 `GET /api/tables/{id}` — Get Table Detail (NEW)

> **FE will call:** `api.get<ApiResponse<TableDetailDto>>("/api/tables/{id}")`

```csharp
[HttpGet("{id:int}")]
public async Task<ActionResult<ApiResponse<TableDetailDto>>> GetTable(int id)
```

**Business logic:**
- Load table with all includes: Status, Type, Zone, Images, active Orders (count), Reservations (upcoming)
- Count active orders: join `Order` table where `Order.TableId == id && Order.StatusCode IN ("PENDING", "IN_PROGRESS")`
- Check errors: any `ServiceError` with `IsResolved == false` for this table (if service errors table exists)
- Get upcoming reservations: `Reservation` where `TableId == id && ReservedTime > DateTime.UtcNow && StatusCode IN ("PENDING", "CONFIRMED")`, take top 5, order by `ReservedTime`
- Return `404` if table not found (soft deleted or non-existent)

### 3.3 `POST /api/tables` — Create Table (NEW)

> **FE will call:** `api.post<ApiResponse<TableManagementDto>>("/api/tables", payload)`

```csharp
[HttpPost]
public async Task<ActionResult<ApiResponse<TableManagementDto>>> CreateTable(
    [FromBody] CreateTableRequest request)
```

**Business logic:**
- Validate `TableCode` uniqueness → return `409 Conflict` with `userMessage: "Table code '{code}' already exists"` if duplicate
- Validate all `LvId` references exist in `LookupValue` table
- Create entity, save
- Return `201 Created` with the new `TableManagementDto`

**Validation rules:**
| Field | Rule |
|-------|------|
| `TableCode` | Required, max 20 chars, unique, alphanumeric + dash |
| `Capacity` | Required, 1–50 |
| `StatusLvId` | Must reference valid TABLE_STATUS lookup |
| `TypeLvId` | Must reference valid TABLE_TYPE lookup |
| `ZoneLvId` | Must reference valid TABLE_ZONE lookup |

### 3.4 `PUT /api/tables/{id}` — Update Table (NEW)

> **FE will call:** `api.put<ApiResponse<TableManagementDto>>("/api/tables/{id}", payload)`

```csharp
[HttpPut("{id:int}")]
public async Task<ActionResult<ApiResponse<TableManagementDto>>> UpdateTable(
    int id, [FromBody] UpdateTableRequest request)
```

**Business logic:**
- Find table by ID → `404` if not found
- If `TableCode` changed, check uniqueness → `409` if duplicate (exclude self)
- Apply only non-null fields from request (partial update)
- Save and return updated `TableManagementDto`

### 3.5 `DELETE /api/tables/{id}` — Delete Table (NEW)

> **FE will call:** `api.delete<ApiResponse<object>>("/api/tables/{id}")`

```csharp
[HttpDelete("{id:int}")]
public async Task<ActionResult<ApiResponse<object>>> DeleteTable(int id)
```

**Business logic:**
- Find table by ID → `404` if not found
- **Guard check:** Query for active orders (`StatusCode IN ("PENDING", "IN_PROGRESS")`) or future reservations (`ReservedTime > now && StatusCode IN ("PENDING", "CONFIRMED")`)
- If blocked → return `409 Conflict`:
  ```json
  {
    "success": false,
    "code": 409,
    "userMessage": "Cannot delete table T-01: 2 active orders and 1 upcoming reservation",
    "data": {
      "activeOrders": 2,
      "upcomingReservations": 1
    }
  }
  ```
- **Soft delete**: set `IsDeleted = true`, `UpdatedAt = DateTime.UtcNow`
- Return `200 OK` with `success: true`

### 3.6 `PATCH /api/tables/{id}/status` — Update Status (NEW)

> **FE will call:** `api.patch<ApiResponse<TableManagementDto>>("/api/tables/{id}/status", { statusLvId })`

```csharp
[HttpPatch("{id:int}/status")]
public async Task<ActionResult<ApiResponse<TableManagementDto>>> UpdateTableStatus(
    int id, [FromBody] UpdateTableStatusRequest request)
```

**Business logic:**
- Find table → `404` if not found
- Validate `StatusLvId` references a valid TABLE_STATUS lookup → `400` if invalid
- **State transition validation** (optional but recommended):
  - `OCCUPIED` → cannot go directly to `AVAILABLE` (must go through `CLEANING` first)
  - `RESERVED` → can only go to `OCCUPIED` or `AVAILABLE`
- Update `StatusLvId`, set `UpdatedAt`
- Return updated `TableManagementDto`

### 3.7 `PATCH /api/tables/{id}/online` — Toggle Online (NEW)

> **FE will call:** `api.patch<ApiResponse<TableManagementDto>>("/api/tables/{id}/online", { isOnline })`

```csharp
[HttpPatch("{id:int}/online")]
public async Task<ActionResult<ApiResponse<TableManagementDto>>> ToggleOnline(
    int id, [FromBody] ToggleOnlineRequest request)
```

**Business logic:**
- Find table → `404` if not found
- If setting offline AND table has active orders → return `409 Conflict` with `userMessage: "Cannot take table offline with active orders"`
- Update `IsOnline`, set `UpdatedAt`
- Return updated DTO

### 3.8 `PATCH /api/tables/bulk-online` — Bulk Zone Toggle (NEW)

> **FE will call:** `api.patch<ApiResponse<BulkOnlineResponse>>("/api/tables/bulk-online", { tableIds, isOnline })`

```csharp
[HttpPatch("bulk-online")]
public async Task<ActionResult<ApiResponse<BulkOnlineResponse>>> BulkToggleOnline(
    [FromBody] BulkOnlineRequest request)
```

**Response DTO:**
```csharp
public class BulkOnlineResponse
{
    public int UpdatedCount { get; set; }
    public List<int> SkippedTableIds { get; set; } = new(); // tables with active orders
}
```

**Business logic:**
- Validate all `TableIds` exist
- If `isOnline = false`: skip tables with active orders (don't fail, just skip and report)
- Bulk update: `UPDATE Tables SET IsOnline = @isOnline, UpdatedAt = @now WHERE TableId IN @tableIds`
- Return count of updated + list of skipped IDs

### 3.9 `POST /api/tables/{id}/images` — Upload Images (NEW)

> **FE will call:** `api.post("/api/tables/{id}/images", formData)` where `formData` has `files[]`

```csharp
[HttpPost("{id:int}/images")]
[Consumes("multipart/form-data")]
public async Task<ActionResult<ApiResponse<TableImagesResponse>>> UploadImages(
    int id, [FromForm] List<IFormFile> files)
```

**Business logic:**
- Find table → `404` if not found
- Validate: max 5 files per request, max 5MB each, image MIME types only (`image/jpeg`, `image/png`, `image/webp`)
- Count existing images: if `existing + new > 10` → `400 Bad Request`
- Upload each file to storage (local disk or cloud CDN)
- Create `TableImage` records with generated URLs
- Return list of new image URLs

### 3.10 `DELETE /api/tables/{id}/images/{imageId}` — Remove Image (NEW)

```csharp
[HttpDelete("{id:int}/images/{imageId:int}")]
public async Task<ActionResult<ApiResponse<object>>> RemoveImage(int id, int imageId)
```

**Business logic:**
- Find `TableImage` where `TableImageId == imageId && TableId == id` → `404` if not found
- Delete file from storage
- Remove DB record
- Return `200 OK`

### 3.11 `GET /api/tables/stats` — Dashboard Statistics (NEW)

> **FE will call:** `api.get<ApiResponse<TableStatsDto>>("/api/tables/stats")`

```csharp
[HttpGet("stats")]
public async Task<ActionResult<ApiResponse<TableStatsDto>>> GetStats()
```

**Response DTO:**
```csharp
public class TableStatsDto
{
    public int TotalTables { get; set; }
    public int TotalCapacity { get; set; }
    public double AvgSeatsPerTable { get; set; }
    public Dictionary<string, int> StatusCounts { get; set; } // key = ValueCode
    public int Online { get; set; }
    public int Offline { get; set; }
    public int ActiveOrders { get; set; }
    public int TablesWithErrors { get; set; }
}
```

**Business logic:**
- Single query with grouping:
  ```sql
  SELECT 
    COUNT(*) as TotalTables,
    SUM(Capacity) as TotalCapacity,
    AVG(CAST(Capacity as float)) as AvgSeatsPerTable,
    SUM(CASE WHEN IsOnline = 1 THEN 1 ELSE 0 END) as Online,
    SUM(CASE WHEN IsOnline = 0 THEN 1 ELSE 0 END) as Offline
  FROM Tables WHERE IsDeleted = 0
  ```
- Status counts: group by `StatusLvId`, join LookupValue for code
- Active orders: count from Orders table where status is PENDING/IN_PROGRESS, group by TableId
- Tables with errors: count tables that have unresolved service errors

### 3.12 `GET /api/reservations/upcoming` — Incoming Reservations (NEW)

> **FE will call:** `api.get<ApiResponse<UpcomingReservationDto[]>>("/api/reservations/upcoming?limit=10")`
>
> **Note:** This may belong in a `ReservationsController` rather than `TablesController`. Place it where it fits your project's existing reservation structure.

```csharp
[HttpGet("upcoming")]
public async Task<ActionResult<ApiResponse<List<IncomingReservationDto>>>> GetUpcoming(
    [FromQuery] int limit = 10)
```

**Response DTO:**
```csharp
public class IncomingReservationDto
{
    public int ReservationId { get; set; }
    public string GuestName { get; set; }
    public int Pax { get; set; }
    public DateTime ReservedTime { get; set; }
    public string TableCode { get; set; }
    public string ZoneCode { get; set; }       // "INDOOR" | "OUTDOOR" | "ROOFTOP"
    public string StatusCode { get; set; }     // "PENDING" | "CONFIRMED"
    public string? PreOrderSummary { get; set; }
}
```

**Business logic:**
- Query `Reservations` where `ReservedTime > DateTime.UtcNow` AND `StatusCode IN ("PENDING", "CONFIRMED")`
- Include `Table` → get `TableCode` and `Zone.ValueCode`
- Build `PreOrderSummary`: if reservation has pre-orders, aggregate as string (e.g. "2× Pho, 1× Spring Roll")
- Order by `ReservedTime ASC`, take `limit`

---

## 4. Service Layer: `ITableService` / `TableService`

### Interface

```csharp
public interface ITableService
{
    Task<PagedResult<TableManagementDto>> GetTablesAsync(TableFilterParams filter);
    Task<TableDetailDto> GetTableByIdAsync(int id);
    Task<TableManagementDto> CreateTableAsync(CreateTableRequest request);
    Task<TableManagementDto> UpdateTableAsync(int id, UpdateTableRequest request);
    Task DeleteTableAsync(int id);
    Task<TableManagementDto> UpdateStatusAsync(int id, UpdateTableStatusRequest request);
    Task<TableManagementDto> ToggleOnlineAsync(int id, bool isOnline);
    Task<BulkOnlineResponse> BulkToggleOnlineAsync(BulkOnlineRequest request);
    Task<List<string>> UploadImagesAsync(int id, List<IFormFile> files);
    Task RemoveImageAsync(int id, int imageId);
    Task<TableStatsDto> GetStatsAsync();
}
```

### Implementation Notes

1. **Inject** `ITableRepository`, `IUnitOfWork`, `ILookupValueRepository`, `IStorageService`
2. **Mapping:** Use AutoMapper or manual projection. Prefer `ProjectTo<Dto>()` in EF queries for performance.
3. **Transactions:** Wrap multi-step operations (create table + create images) in transactions via `IUnitOfWork`
4. **Validation in service, not controller:** Throw custom exceptions that a middleware translates to `ApiResponse`:
   - `NotFoundException` → 404
   - `ConflictException` → 409
   - `ValidationException` → 400
5. **Lookup resolution:** When request sends `StatusLvId`, verify it exists and belongs to category `"TABLE_STATUS"`. Reject with `400` if the LvId belongs to a different category.

---

## 5. Repository Layer

### `ITableRepository`

```csharp
public interface ITableRepository
{
    Task<(List<Table> items, int totalCount)> GetPagedAsync(TableFilterParams filter);
    Task<Table?> GetByIdAsync(int id, bool includeDetails = false);
    Task<bool> ExistsAsync(int id);
    Task<bool> TableCodeExistsAsync(string code, int? excludeId = null);
    Task<int> CountActiveOrdersAsync(int tableId);
    Task<int> CountUpcomingReservationsAsync(int tableId);
    void Add(Table table);
    void Update(Table table);
}
```

### Query Optimization

- **List endpoint:** Use `.AsNoTracking()` + projection to DTO in the query (no entity materialization)
- **Includes:** Be explicit — don't use `.Include()` on list queries, use `Select` projection instead:
  ```csharp
  .Select(t => new TableManagementDto
  {
      TableId = t.TableId,
      TableCode = t.TableCode,
      Capacity = t.Capacity,
      IsOnline = t.IsOnline,
      StatusId = t.StatusLvId,
      StatusCode = t.Status.ValueCode,
      StatusName = t.Status.DisplayName, // or i18n field
      TypeId = t.TypeLvId,
      TypeName = t.Type.DisplayName,
      ZoneId = t.ZoneLvId,
      ZoneName = t.Zone.DisplayName,
  })
  ```
- **Detail endpoint** needs `.Include()` for navigation properties (Images, Status, Type, Zone)
- **Stats endpoint:** Use raw SQL or EF GroupBy for aggregation — avoid loading all entities

---

## 6. Seed Data

Ensure these lookup values exist in migration seeds or data seeder:

```csharp
// TABLE_STATUS category
new LookupValue { ValueCode = "AVAILABLE",      CategoryCode = "TABLE_STATUS", SortOrder = 1, DisplayName = "Available" },
new LookupValue { ValueCode = "OCCUPIED",        CategoryCode = "TABLE_STATUS", SortOrder = 2, DisplayName = "Occupied" },
new LookupValue { ValueCode = "RESERVED",        CategoryCode = "TABLE_STATUS", SortOrder = 3, DisplayName = "Reserved" },
new LookupValue { ValueCode = "LOCKED",          CategoryCode = "TABLE_STATUS", SortOrder = 4, DisplayName = "Locked" },

// TABLE_TYPE category
new LookupValue { ValueCode = "REGULAR",         CategoryCode = "TABLE_TYPE",   SortOrder = 1, DisplayName = "Regular" },
new LookupValue { ValueCode = "VIP",             CategoryCode = "TABLE_TYPE",   SortOrder = 2, DisplayName = "VIP" },
new LookupValue { ValueCode = "BOOTH",           CategoryCode = "TABLE_TYPE",   SortOrder = 3, DisplayName = "Booth" },
new LookupValue { ValueCode = "BAR",             CategoryCode = "TABLE_TYPE",   SortOrder = 4, DisplayName = "Bar" },
new LookupValue { ValueCode = "HIGH_TOP",        CategoryCode = "TABLE_TYPE",   SortOrder = 5, DisplayName = "High Top" },

// TABLE_ZONE category
new LookupValue { ValueCode = "INDOOR",          CategoryCode = "TABLE_ZONE",   SortOrder = 1, DisplayName = "Indoor" },
new LookupValue { ValueCode = "OUTDOOR",         CategoryCode = "TABLE_ZONE",   SortOrder = 2, DisplayName = "Outdoor" },
new LookupValue { ValueCode = "ROOFTOP",         CategoryCode = "TABLE_ZONE",   SortOrder = 3, DisplayName = "Rooftop" },
```

---

## 7. Implementation Priority & Checklist

Implement endpoints in this order (dependencies first):

| # | Endpoint | Method | Priority | Depends On |
|---|----------|--------|----------|------------|
| 1 | `/api/tables` | GET | 🔴 **P0** | Lookup seeds |
| 2 | `/api/tables/{id}` | GET | 🔴 **P0** | #1 |
| 3 | `/api/tables` | POST | 🔴 **P0** | Lookup validation |
| 4 | `/api/tables/{id}` | PUT | 🔴 **P0** | #1 |
| 5 | `/api/tables/{id}` | DELETE | 🔴 **P0** | Active orders / reservation check |
| 6 | `/api/tables/{id}/status` | PATCH | 🟡 **P1** | Lookup validation |
| 7 | `/api/tables/{id}/online` | PATCH | 🟡 **P1** | Active order guard |
| 8 | `/api/tables/bulk-online` | PATCH | 🟡 **P1** | #7 |
| 9 | `/api/tables/stats` | GET | 🟡 **P1** | Orders/errors aggregation |
| 10 | `/api/tables/{id}/images` | POST | 🟢 **P2** | Storage service |
| 11 | `/api/tables/{id}/images/{imgId}` | DELETE | 🟢 **P2** | #10 |
| 12 | `/api/reservations/upcoming` | GET | 🟢 **P2** | Reservation entity |

### Per-endpoint checklist:

For **each** endpoint, ensure:

- [ ] Controller action created with correct `[Http*]` attribute and route
- [ ] Request DTO with `[Required]`, `[Range]`, `[MaxLength]` data annotations
- [ ] Service method implementing business logic
- [ ] Repository method with optimized EF query
- [ ] Error cases return proper `ApiResponse` with `userMessage`
- [ ] `[Authorize]` applied (with role claims if needed)
- [ ] Unit test for service method
- [ ] Integration test for controller endpoint

---

## 8. FE ↔ BE Contract Summary

### Existing endpoint (already implemented):

| Method | Path | FE Type | Status |
|--------|------|---------|--------|
| GET | `/api/tables?pageIndex=&pageSize=` | `ApiResponse<PagedResult<TableManagementDto>>` | ✅ Exists |

### New endpoints needed:

| Method | Path | FE Expects | Notes |
|--------|------|-----------|-------|
| GET | `/api/tables/{id}` | `ApiResponse<TableDetailDto>` | Include images, orders count, reservations |
| POST | `/api/tables` | `ApiResponse<TableManagementDto>` | 409 on duplicate code |
| PUT | `/api/tables/{id}` | `ApiResponse<TableManagementDto>` | Partial update |
| DELETE | `/api/tables/{id}` | `ApiResponse<object>` | 409 if active orders/reservations |
| PATCH | `/api/tables/{id}/status` | `ApiResponse<TableManagementDto>` | Send `{ statusLvId }` |
| PATCH | `/api/tables/{id}/online` | `ApiResponse<TableManagementDto>` | Send `{ isOnline }` |
| PATCH | `/api/tables/bulk-online` | `ApiResponse<BulkOnlineResponse>` | Send `{ tableIds, isOnline }` |
| POST | `/api/tables/{id}/images` | `ApiResponse<{ images: string[] }>` | multipart/form-data |
| DELETE | `/api/tables/{id}/images/{imgId}` | `ApiResponse<object>` | |
| GET | `/api/tables/stats` | `ApiResponse<TableStatsDto>` | Aggregated dashboard data |
| GET | `/api/reservations/upcoming?limit=` | `ApiResponse<IncomingReservationDto[]>` | Ordered by time ASC |

### Important FE mapping notes:

The FE currently maps DTO fields with this logic (in `table-management.tsx`):
```typescript
status: (dto.statusCode || "AVAILABLE") as TableStatus
type:   (dto.typeName?.toUpperCase().replace(/[- ]/g, "_") || "REGULAR") as TableType
zone:   (dto.zoneName?.toUpperCase().replace(/[- ]/g, "_") || "INDOOR") as TableZone
```

This means:
- `statusCode` **must** be the exact `ValueCode` from LookupValue (e.g. `"AVAILABLE"`, not `"Available"`)
- `typeName` is the display name — FE converts it to code with `toUpperCase().replace(/ /g, "_")`. So `"High Top"` becomes `"HIGH_TOP"`. **Ideally, also return `typeCode` so FE can rely on that instead.**
- `zoneName` — same conversion. `"Indoor"` → `"INDOOR"`.

**Recommendation:** Add `typeCode` and `zoneCode` to `TableManagementDto` so the FE doesn't need string manipulation. Then update the FE mapping to use codes directly.

---

## 9. Error Code Reference

| HTTP Status | `subCode` | When | `userMessage` example |
|-------------|-----------|------|-----------------------|
| 400 | 4001 | Invalid request body | "Capacity must be between 1 and 50" |
| 400 | 4002 | Invalid lookup reference | "Invalid table type" |
| 404 | 4041 | Table not found | "Table not found" |
| 409 | 4091 | Duplicate table code | "Table code 'T-01' already exists" |
| 409 | 4092 | Cannot delete — blocked | "Cannot delete: 2 active orders" |
| 409 | 4093 | Cannot go offline — active orders | "Cannot take offline with active orders" |
| 500 | 5001 | Unexpected server error | "Something went wrong. Please try again." |
