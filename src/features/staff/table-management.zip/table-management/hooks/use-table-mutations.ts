import { useMutation, useQueryClient } from "@tanstack/react-query";
import { toast } from "sonner";
import { tableService } from "../services/table.service";
import { TABLE_LIST_QUERY_KEY } from "./use-tables";
import { TABLE_DETAIL_QUERY_KEY } from "./use-table-detail";
import type {
  CreateTableRequest,
  UpdateTableRequest,
  UpdateTableStatusRequest,
  TableManagementDto,
} from "../types";

// ── Helpers ──

function invalidateTableQueries(queryClient: ReturnType<typeof useQueryClient>) {
  queryClient.invalidateQueries({ queryKey: [TABLE_LIST_QUERY_KEY] });
  queryClient.invalidateQueries({ queryKey: [TABLE_DETAIL_QUERY_KEY] });
}

function getApiErrorMessage(error: unknown): string {
  const err = error as { response?: { data?: { userMessage?: string } } };
  return err?.response?.data?.userMessage || (error as Error).message || "Something went wrong";
}

// ── Create ──

export function useCreateTable(callbacks?: {
  onSuccess?: (data: TableManagementDto) => void;
  onError?: (error: Error) => void;
}) {
  const queryClient = useQueryClient();

  return useMutation<TableManagementDto, Error, CreateTableRequest>({
    mutationFn: (data) => tableService.createTable(data),
    onSuccess: (data) => {
      toast.success("Table created", {
        description: `Table "${data.tableCode}" has been created successfully.`,
      });
      invalidateTableQueries(queryClient);
      callbacks?.onSuccess?.(data);
    },
    onError: (error) => {
      toast.error("Failed to create table", {
        description: getApiErrorMessage(error),
      });
      callbacks?.onError?.(error);
    },
  });
}

// ── Update ──

export function useUpdateTable(callbacks?: {
  onSuccess?: (data: TableManagementDto) => void;
  onError?: (error: Error) => void;
}) {
  const queryClient = useQueryClient();

  return useMutation<TableManagementDto, Error, { id: number; data: UpdateTableRequest }>({
    mutationFn: ({ id, data }) => tableService.updateTable(id, data),
    onSuccess: (data) => {
      toast.success("Table updated", {
        description: `Table "${data.tableCode}" has been updated.`,
      });
      invalidateTableQueries(queryClient);
      callbacks?.onSuccess?.(data);
    },
    onError: (error) => {
      toast.error("Failed to update table", {
        description: getApiErrorMessage(error),
      });
      callbacks?.onError?.(error);
    },
  });
}

// ── Delete ──

export function useDeleteTable(callbacks?: {
  onSuccess?: () => void;
  onError?: (error: Error) => void;
}) {
  const queryClient = useQueryClient();

  return useMutation<void, Error, number>({
    mutationFn: (id) => tableService.deleteTable(id),
    onSuccess: () => {
      toast.success("Table deleted", {
        description: "The table has been removed.",
      });
      invalidateTableQueries(queryClient);
      callbacks?.onSuccess?.();
    },
    onError: (error) => {
      toast.error("Failed to delete table", {
        description: getApiErrorMessage(error),
      });
      callbacks?.onError?.(error);
    },
  });
}

// ── Update Status ──

export function useUpdateTableStatus(callbacks?: {
  onSuccess?: (data: TableManagementDto) => void;
  onError?: (error: Error) => void;
}) {
  const queryClient = useQueryClient();

  return useMutation<TableManagementDto, Error, { id: number; data: UpdateTableStatusRequest }>({
    mutationFn: ({ id, data }) => tableService.updateTableStatus(id, data),
    onSuccess: (data) => {
      toast.success("Status updated", {
        description: `Table "${data.tableCode}" is now ${data.statusName}.`,
      });
      invalidateTableQueries(queryClient);
      callbacks?.onSuccess?.(data);
    },
    onError: (error) => {
      toast.error("Failed to update status", {
        description: getApiErrorMessage(error),
      });
      callbacks?.onError?.(error);
    },
  });
}
