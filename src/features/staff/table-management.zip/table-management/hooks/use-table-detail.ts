import { useQuery } from "@tanstack/react-query";
import { tableService } from "../services/table.service";

export const TABLE_DETAIL_QUERY_KEY = "table-detail";

/**
 * Fetches full detail for a single table (images, reservations, etc.).
 * Enabled only when id is provided.
 */
export function useTableDetail(id: number | null) {
  return useQuery({
    queryKey: [TABLE_DETAIL_QUERY_KEY, id],
    queryFn: () => tableService.getTableDetail(id!),
    enabled: !!id && id > 0,
  });
}
