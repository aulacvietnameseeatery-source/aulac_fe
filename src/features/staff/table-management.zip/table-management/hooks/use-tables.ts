import { useQuery } from "@tanstack/react-query";
import { tableService } from "../services/table.service";
import type { TableListParams } from "../types";

export const TABLE_LIST_QUERY_KEY = "tables";

/**
 * Fetches the paginated table list.
 * Re-fetches when params change.
 */
export function useTables(params?: TableListParams) {
  return useQuery({
    queryKey: [TABLE_LIST_QUERY_KEY, params],
    queryFn: () => tableService.getTables(params),
  });
}
