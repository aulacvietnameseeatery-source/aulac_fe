import { api } from "@/lib/http";
import type { ApiResponse, PagedResult } from "@/types/api-response.types";
import type {
  TableManagementDto,
  TableDetailDto,
  CreateTableRequest,
  UpdateTableRequest,
  UpdateTableStatusRequest,
  TableListParams,
} from "../types";

export const tableService = {
  /**
   * GET /api/tables — Paginated list with optional filters
   */
  async getTables(params?: TableListParams): Promise<PagedResult<TableManagementDto>> {
    const query = new URLSearchParams();

    if (params?.pageIndex) query.append("pageIndex", params.pageIndex.toString());
    if (params?.pageSize) query.append("pageSize", params.pageSize.toString());
    if (params?.search) query.append("search", params.search);
    if (params?.zoneId) query.append("zoneId", params.zoneId.toString());
    if (params?.typeId) query.append("typeId", params.typeId.toString());
    if (params?.statusId) query.append("statusId", params.statusId.toString());
    if (params?.isOnline !== undefined) query.append("isOnline", params.isOnline.toString());

    const qs = query.toString();
    const path = `/api/tables${qs ? `?${qs}` : ""}`;

    const response = await api.get<ApiResponse<PagedResult<TableManagementDto>>>(path);
    return response.data;
  },

  /**
   * GET /api/tables/{id} — Full detail including images, orders, reservations
   */
  async getTableDetail(id: number): Promise<TableDetailDto> {
    const response = await api.get<ApiResponse<TableDetailDto>>(`/api/tables/${id}`);
    return response.data;
  },

  /**
   * POST /api/tables — Create a new table
   */
  async createTable(data: CreateTableRequest): Promise<TableManagementDto> {
    const response = await api.post<ApiResponse<TableManagementDto>, CreateTableRequest>(
      "/api/tables",
      data,
    );
    return response.data;
  },

  /**
   * PUT /api/tables/{id} — Partial update
   */
  async updateTable(id: number, data: UpdateTableRequest): Promise<TableManagementDto> {
    const response = await api.put<ApiResponse<TableManagementDto>, UpdateTableRequest>(
      `/api/tables/${id}`,
      data,
    );
    return response.data;
  },

  /**
   * DELETE /api/tables/{id} — Soft delete
   */
  async deleteTable(id: number): Promise<void> {
    await api.delete<ApiResponse<object>>(`/api/tables/${id}`);
  },

  /**
   * PATCH /api/tables/{id}/status — Update status with transition validation
   */
  async updateTableStatus(id: number, data: UpdateTableStatusRequest): Promise<TableManagementDto> {
    const response = await api.patch<ApiResponse<TableManagementDto>, UpdateTableStatusRequest>(
      `/api/tables/${id}/status`,
      data,
    );
    return response.data;
  },
};
