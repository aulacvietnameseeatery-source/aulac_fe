# Table Management — Features & Endpoint Specification

> Accurate inventory of the current frontend implementation and all backend endpoints required.
> Last updated: **2026-02-26**

---

## 1. Project Structure

```
src/features/staff/table-management/
├── table-management.tsx          # Page-level orchestrator
├── data.ts                       # Mock data (22 tables, ALL_STATUSES, ALL_TYPES, ALL_ZONES)
├── types/
│   ├── index.ts                  # Barrel exports
│   └── table.types.ts            # Types + constants
├── components/
│   ├── index.ts                  # Barrel exports
│   ├── dashboard-summary.tsx     # KPI overview + status bar + incoming reservations
│   ├── filter-bar.tsx            # Zone tabs + keyword search + type/status/online combos
│   ├── zone-section.tsx          # Collapsible zone card with table grid
│   ├── table-card.tsx            # Individual table card with context menu
│   ├── table-modal.tsx           # Add/Edit dialog (form + QR + media upload)
│   ├── table-detail-panel.tsx    # Right-side drawer with full details
│   ├── delete-modal.tsx          # Delete confirmation dialog
│   ├── status-badge.tsx          # Reusable status badge component
│   └── table-legend.tsx          # Status color legend (currently unused in layout)
├── hooks/                        # Empty — no API hooks yet
└── services/                     # Empty — no API services yet
```

---

## 2. Feature Inventory

### 2.1 Dashboard Overview (`dashboard-summary.tsx`)

| ID | Feature | Status | Description |
|----|---------|--------|-------------|
| F-01 | **Status progress bar** | ✅ Implemented | Horizontal stacked bar showing count per status (AVAILABLE, OCCUPIED, RESERVED, CLEANING, OUT_OF_SERVICE) with % widths and inline color legend. |
| F-02 | **KPI: Total Capacity** | ✅ Implemented | StatCard showing total seats across all tables + average seats/table. |
| F-03 | **KPI: Online / Offline** | ✅ Implemented | StatCard showing online count with inline offline count + WifiOff icon. |
| F-04 | **KPI: Active Orders** | ✅ Implemented | StatCard summing `activeOrders` across all tables. Blue accent when > 0. |
| F-05 | **KPI: Errors** | ✅ Implemented | StatCard counting tables with `hasErrors === true`. Orange accent when > 0. |
| F-06 | **Incoming Reservations strip** | ✅ Implemented (mock) | Horizontal-scroll row of `ReservationCard` components (w-44, vertical layout). Shows time badge, relative countdown, guest name, pax, table code, zone, pre-order summary, status pill (Confirmed/Pending). "See all" underline link → `/dashboard/reservation`. |
| F-07 | **Header summary** | ✅ Implemented | Title "Overview" with total tables count + total seats. |

### 2.2 Filter Bar (`filter-bar.tsx`)

| ID | Feature | Status | Description |
|----|---------|--------|-------------|
| F-08 | **Zone tabs** | ✅ Implemented | Horizontal `Tabs` component with "All Zones" + each zone (INDOOR, OUTDOOR, ROOFTOP, PATIO, VIP_ROOM). |
| F-09 | **Keyword search** | ✅ Implemented | `KeywordSearch` component filtering by table code. |
| F-10 | **Type combo** | ✅ Implemented | `ALCombobox` with All Types + REGULAR/VIP/BOOTH/BAR/HIGH_TOP. Clearable, not searchable, size sm. |
| F-11 | **Status combo** | ✅ Implemented | `ALCombobox` with All Statuses + each status. |
| F-12 | **Online combo** | ✅ Implemented | `ALCombobox` with ALL/ONLINE/OFFLINE options. |

### 2.3 Zone Section (`zone-section.tsx`)

| ID | Feature | Status | Description |
|----|---------|--------|-------------|
| F-13 | **Zone card** | ✅ Implemented | Card per zone with header (zone label, subtitle, table count badge). |
| F-14 | **Collapse toggle** | ✅ Implemented | ChevronUp/ChevronDown button; clicking header or button toggles. `collapsed` prop controlled by parent. |
| F-15 | **Zone stats pills** | ✅ Implemented | Hidden on mobile. Shows: available count, total seats, active orders, error count in the header action area. |
| F-16 | **Zone online/offline toggle** | ✅ Implemented | Wifi/WifiOff button to bulk-set all tables in zone online or offline. |
| F-17 | **Mini status bar** | ✅ Implemented | Small 1.5px-height bar inside content showing available/occupied/reserved proportions. |
| F-18 | **Scrollable table grid** | ✅ Implemented | `maxHeight` prop (default 520px) with `overflow-y-auto`. Grid responsive: 2→3→4→5→6 columns. |
| F-19 | **Empty zone hidden** | ✅ Implemented | Returns `null` if filtered tables for zone is empty. |

### 2.4 Table Card (`table-card.tsx`)

| ID | Feature | Status | Description |
|----|---------|--------|-------------|
| F-20 | **Card display** | ✅ Implemented | Image (h-28), table code, status badge, offline label, error label. Colored border per status. |
| F-21 | **Click to select** | ✅ Implemented | Clicking card triggers `onSelect` → opens detail panel. |
| F-22 | **Context menu** | ✅ Implemented | Three-dot button (visible on hover) with portal-based dropdown: View Details, Edit, status quick-change actions, Delete. |
| F-23 | **Quick status change** | ✅ Implemented | Context menu lists all statuses except current. Triggers `onStatusChange`. |
| F-24 | **Offline opacity** | ✅ Implemented | Cards with `isOnline === false` rendered at 55% opacity. |
| F-25 | **Capacity & type display** | ✅ Implemented | Shows capacity + type label below table code in card footer. |

### 2.5 Table Modal (`table-modal.tsx`)

| ID | Feature | Status | Description |
|----|---------|--------|-------------|
| F-26 | **Add mode** | ✅ Implemented (mock) | Creates new table with auto-incremented ID. Form: tableCode, capacity, zone (ALCombobox), type (ALCombobox), status (ALCombobox), isOnline (Switch). |
| F-27 | **Edit mode** | ✅ Implemented (mock) | Pre-fills form from selected table. Updates in local state. |
| F-28 | **QR code generate** | ✅ Implemented (client) | Client-side `QRCodeCanvas` (qrcode.react). URL: `/order?table={tableCode}`. |
| F-29 | **QR code preview** | ✅ Implemented | Toggle preview showing canvas + URL text. |
| F-30 | **QR code download** | ✅ Implemented (client) | Downloads canvas as PNG (`qr-{tableCode}.png`). |
| F-31 | **Image upload** | ✅ Implemented (client) | `FileUpload` component — drop zone, multiple files, max 5, max 5MB each. Creates blob URLs (not server-persisted). |
| F-32 | **Existing image management** | ✅ Implemented (client) | Shows existing images in edit mode with X button to remove. |

### 2.6 Detail Panel (`table-detail-panel.tsx`)

| ID | Feature | Status | Description |
|----|---------|--------|-------------|
| F-33 | **Drawer display** | ✅ Implemented | Right-side `Drawer` (max-w-md). Shows: header with table code + online badge + status badge. |
| F-34 | **Table image** | ✅ Implemented | Full-width image (h-44) at top of content. |
| F-35 | **Info grid** | ✅ Implemented | 2-column grid: Zone, Type, Capacity, Connection status. |
| F-36 | **Active orders section** | ✅ Implemented (placeholder) | Shows count with amber alert box, or "No active orders" text. |
| F-37 | **Error section** | ✅ Implemented (placeholder) | Red alert box when `hasErrors === true`. |
| F-38 | **QR code section** | ✅ Implemented | QrCode icon + URL text when `qrCodeUrl` exists. |
| F-39 | **Quick status change** | ✅ Implemented | Row of status pills; current status highlighted; clicking changes status. |
| F-40 | **Footer actions** | ✅ Implemented | Edit + Delete buttons. |

### 2.7 Delete Modal (`delete-modal.tsx`)

| ID | Feature | Status | Description |
|----|---------|--------|-------------|
| F-41 | **Delete confirmation** | ✅ Implemented (mock) | Simple dialog with trash icon, title, description, Close + Delete buttons. No guard for active orders/reservations. |

### 2.8 Orchestrator (`table-management.tsx`)

| ID | Feature | Status | Description |
|----|---------|--------|-------------|
| F-42 | **Page header** | ✅ Implemented | Title "Table Management", subtitle with filtered count + available count. Refresh + Add Table buttons. |
| F-43 | **Filter integration** | ✅ Implemented | Applies zone/type/status/online/search filters via `useMemo`. |
| F-44 | **Group by zone** | ✅ Implemented | Groups filtered tables into zone buckets, renders `ZoneSection` per zone. |
| F-45 | **Zone collapse state** | ✅ Implemented | `collapsedZones` Set state; toggle handler passed to each `ZoneSection`. |
| F-46 | **Zone online toggle** | ✅ Implemented | Handler sets all tables in zone online/offline. |
| F-47 | **CRUD operations** | ✅ Implemented (mock) | Add, Edit, Delete all work on local state. Detail panel synced on edit. |
| F-48 | **Status change** | ✅ Implemented (mock) | Updates table status in local state. Syncs detail panel. |
| F-49 | **Empty state** | ✅ Implemented | "No tables found" message when filters yield 0 results. |
| F-50 | **Refresh** | ✅ Implemented (mock) | Resets to `mockTables`, default filters, and clears collapsed zones. |

### 2.9 Shared Components

| ID | Feature | File | Description |
|----|---------|------|-------------|
| F-51 | **StatusBadge** | `status-badge.tsx` | Reusable badge with dot + label. Maps status → Badge variant (success/destructive/warning/info/secondary). Sizes: sm, md. |
| F-52 | **TableLegend** | `table-legend.tsx` | Color legend for all statuses + Error + Offline. Currently **not rendered** (legend embedded in dashboard status bar). |

---

## 3. Data Models

### 3.1 RestaurantTable

```typescript
interface RestaurantTable {
  tableId: number;
  tableCode: string;
  capacity: number;
  status: "AVAILABLE" | "OCCUPIED" | "RESERVED" | "CLEANING" | "OUT_OF_SERVICE";
  type: "REGULAR" | "VIP" | "BOOTH" | "BAR" | "HIGH_TOP";
  zone: "INDOOR" | "OUTDOOR" | "ROOFTOP" | "PATIO" | "VIP_ROOM";
  isOnline: boolean;
  qrCodeUrl?: string;
  qrCodeGenerated?: boolean;
  image?: string;
  images?: string[];
  activeOrders: number;
  hasErrors: boolean;
}
```

### 3.2 TableFormData

```typescript
interface TableFormData {
  tableCode: string;
  capacity: number;
  status: TableStatus | "";
  type: TableType | "";
  zone: TableZone | "";
  isOnline: boolean;
  qrCodeUrl?: string;
  qrCodeGenerated?: boolean;
  images?: string[];
}
```

### 3.3 TableFilters

```typescript
interface TableFilters {
  zone: TableZone | "ALL";
  type: TableType | "ALL";
  status: TableStatus | "ALL";
  isOnline: "ALL" | "ONLINE" | "OFFLINE";
  search: string;
}
```

### 3.4 IncomingReservation (dashboard local)

```typescript
interface IncomingReservation {
  reservationId: number;
  guestName: string;
  pax: number;
  reservedTime: string;   // ISO string
  tableCode: string;
  zone: TableZone;
  status: "PENDING" | "CONFIRMED";
  preOrderSummary?: string;
}
```

### 3.5 Constants

| Constant | Type | Keys |
|----------|------|------|
| `TABLE_STATUS_CONFIG` | `Record<TableStatus, StatusConfig>` | label, dotColor, bgColor, borderColor, textColor |
| `TABLE_TYPE_LABELS` | `Record<TableType, string>` | REGULAR → "Regular", VIP → "VIP", etc. |
| `TABLE_ZONE_LABELS` | `Record<TableZone, string>` | INDOOR → "Indoor", OUTDOOR → "Outdoor", etc. |
| `TABLE_ZONE_ICONS` | `Record<TableZone, string>` | INDOOR → "🏠", OUTDOOR → "🌿", ROOFTOP → "🌤️", PATIO → "☂️", VIP_ROOM → "👑" |

---

## 4. Core API Endpoints

> These endpoints are required to replace the current mock data with a real backend.

### 4.1 Table CRUD

#### `GET /api/v1/tables`

List all tables with optional filtering and pagination.

**Query Parameters:**

| Param | Type | Default | Description |
|-------|------|---------|-------------|
| `zone` | string | — | Filter by zone |
| `type` | string | — | Filter by table type |
| `status` | string | — | Filter by status |
| `isOnline` | boolean | — | Filter online/offline |
| `search` | string | — | Search table code (partial match) |
| `pageIndex` | number | 1 | Page number |
| `pageSize` | number | 50 | Items per page |

**Response 200:**

```json
{
  "success": true,
  "data": {
    "items": [
      {
        "tableId": 1,
        "tableCode": "T-01",
        "capacity": 4,
        "status": "AVAILABLE",
        "type": "REGULAR",
        "zone": "INDOOR",
        "isOnline": true,
        "qrCodeUrl": "/order?table=T-01",
        "qrCodeGenerated": true,
        "image": "/images/tables/t-01.png",
        "images": ["/images/tables/t-01.png"],
        "activeOrders": 0,
        "hasErrors": false
      }
    ],
    "totalCount": 22,
    "pageIndex": 1,
    "pageSize": 50
  }
}
```

**Used by:** `table-management.tsx` (replaces `mockTables`), `dashboard-summary.tsx` (KPI computation)

---

#### `GET /api/v1/tables/:tableId`

Get single table details.

**Response 200:**

```json
{
  "success": true,
  "data": {
    "tableId": 1,
    "tableCode": "T-01",
    "capacity": 4,
    "status": "AVAILABLE",
    "type": "REGULAR",
    "zone": "INDOOR",
    "isOnline": true,
    "qrCodeUrl": "/order?table=T-01",
    "qrCodeGenerated": true,
    "image": "/images/tables/t-01.png",
    "images": ["/images/tables/t-01.png"],
    "activeOrders": 0,
    "hasErrors": false,
    "upcomingReservations": [
      {
        "reservationId": 55,
        "guestName": "John",
        "pax": 4,
        "reservedTime": "2026-02-26T18:00:00Z",
        "status": "CONFIRMED"
      }
    ]
  }
}
```

**Used by:** `table-detail-panel.tsx`

---

#### `POST /api/v1/tables`

Create a new table.

**Request Body:**

```json
{
  "tableCode": "T-23",
  "capacity": 4,
  "status": "AVAILABLE",
  "type": "REGULAR",
  "zone": "INDOOR",
  "isOnline": true
}
```

**Response 201:**

```json
{
  "success": true,
  "data": { "tableId": 23, "tableCode": "T-23", "..." : "..." }
}
```

**Validation:** `tableCode` must be unique. Returns `409 Conflict` if duplicate.  
**Used by:** `table-modal.tsx` (add mode) → F-26

---

#### `PUT /api/v1/tables/:tableId`

Update an existing table.

**Request Body:** Same as POST (partial update allowed).  
**Response 200:** Updated table object.  
**Used by:** `table-modal.tsx` (edit mode) → F-27

---

#### `DELETE /api/v1/tables/:tableId`

Delete a table.

**Response 200:**

```json
{ "success": true }
```

**Validation:** Should return `409 Conflict` if table has active orders or future reservations. Response body should include blocking reason.  
**Used by:** `delete-modal.tsx` → F-41

---

### 4.2 Status & Online Toggle

#### `PATCH /api/v1/tables/:tableId/status`

Update table status only.

**Request Body:**

```json
{ "status": "OCCUPIED" }
```

**Response 200:** Updated table object.  
**Used by:** `table-card.tsx` context menu → F-23, `table-detail-panel.tsx` quick status change → F-39

---

#### `PATCH /api/v1/tables/:tableId/online`

Toggle single table online/offline.

**Request Body:**

```json
{ "isOnline": false }
```

**Response 200:** Updated table object.  
**Used by:** Future inline toggle on card/detail panel

---

#### `PATCH /api/v1/tables/bulk-online`

Bulk toggle online/offline for multiple tables (zone toggle).

**Request Body:**

```json
{
  "tableIds": [1, 2, 3, 4, 5],
  "isOnline": true
}
```

**Response 200:**

```json
{ "success": true, "updatedCount": 5 }
```

**Used by:** `zone-section.tsx` zone online toggle → F-16

---

### 4.3 QR Code

#### `POST /api/v1/tables/:tableId/qr-code`

Generate and persist a QR code server-side.

**Request Body:**

```json
{
  "url": "/order?table=T-01"
}
```

**Response 200:**

```json
{
  "success": true,
  "data": {
    "qrCodeUrl": "/order?table=T-01",
    "qrCodeImageUrl": "https://cdn.example.com/qr/table-1.png"
  }
}
```

**Used by:** `table-modal.tsx` Generate QR button → F-28 (currently client-only)

---

### 4.4 Media Upload

#### `POST /api/v1/tables/:tableId/images`

Upload table images.

**Request:** `multipart/form-data` with `files[]` field.  
**Constraints:** Max 5 files, max 5MB each, image/* MIME types only.

**Response 200:**

```json
{
  "success": true,
  "data": {
    "images": [
      "https://cdn.example.com/tables/1/img-1.jpg",
      "https://cdn.example.com/tables/1/img-2.jpg"
    ]
  }
}
```

**Used by:** `table-modal.tsx` file upload → F-31 (currently client blob URLs only)

---

#### `DELETE /api/v1/tables/:tableId/images/:imageId`

Remove a specific image from a table.

**Response 200:**

```json
{ "success": true }
```

**Used by:** `table-modal.tsx` existing image X button → F-32

---

### 4.5 Dashboard / Statistics

#### `GET /api/v1/tables/stats`

Aggregated statistics for the overview dashboard.

**Response 200:**

```json
{
  "success": true,
  "data": {
    "totalTables": 22,
    "totalCapacity": 108,
    "avgSeatsPerTable": 4.9,
    "statusCounts": {
      "AVAILABLE": 9,
      "OCCUPIED": 5,
      "RESERVED": 3,
      "CLEANING": 2,
      "OUT_OF_SERVICE": 1
    },
    "online": 20,
    "offline": 2,
    "activeOrders": 8,
    "tablesWithErrors": 2
  }
}
```

**Used by:** `dashboard-summary.tsx` → F-01 through F-05 (currently computed client-side from full table list)

---

### 4.6 Incoming Reservations

#### `GET /api/v1/reservations/upcoming`

List upcoming reservations for the table management dashboard widget.

**Query Parameters:**

| Param | Type | Default | Description |
|-------|------|---------|-------------|
| `limit` | number | 10 | Max number of reservations |
| `fromNow` | boolean | true | Only future reservations |

**Response 200:**

```json
{
  "success": true,
  "data": [
    {
      "reservationId": 101,
      "guestName": "Nguyen Van A",
      "pax": 4,
      "reservedTime": "2026-02-26T12:30:00Z",
      "tableCode": "T-03",
      "zone": "INDOOR",
      "status": "CONFIRMED",
      "preOrderSummary": "2× Pho, 1× Spring Roll"
    }
  ]
}
```

**Used by:** `dashboard-summary.tsx` → F-06 (currently `MOCK_RESERVATIONS` array)

---

## 5. Future / Extended Endpoints

> These endpoints support planned features not yet implemented in the frontend.

### 5.1 Orders Integration

| Method | Path | Description | Frontend Feature |
|--------|------|-------------|-----------------|
| `GET` | `/api/v1/tables/:tableId/orders` | List active orders for a table | Detail panel — orders list |
| `POST` | `/api/v1/tables/:tableId/orders` | Create order linked to table | POS / ordering integration |

### 5.2 Reservations Integration

| Method | Path | Description | Frontend Feature |
|--------|------|-------------|-----------------|
| `GET` | `/api/v1/tables/:tableId/reservations` | List upcoming reservations for a specific table | Detail panel — reservation list |
| `POST` | `/api/v1/reservations` | Create a reservation linked to a table | Reserve action |
| `DELETE` | `/api/v1/reservations/:reservationId` | Cancel a reservation | Cancel action in detail panel |

### 5.3 Service Errors

| Method | Path | Description | Frontend Feature |
|--------|------|-------------|-----------------|
| `GET` | `/api/v1/tables/:tableId/errors` | List service errors for a table | Detail panel — error list |
| `POST` | `/api/v1/tables/:tableId/errors` | Report a new error | Error reporting UI |
| `PATCH` | `/api/v1/tables/:tableId/errors/:errorId/resolve` | Mark error as resolved | Error resolution action |

### 5.4 Real-time

| Method | Path | Description | Frontend Feature |
|--------|------|-------------|-----------------|
| `WS` | `/ws/tables` | WebSocket for live table status updates | Real-time status sync |

---

## 6. Endpoint → Feature Mapping

| Endpoint | Features |
|----------|----------|
| `GET /tables` | F-01–F-07, F-08–F-12, F-13–F-19, F-42–F-49 |
| `GET /tables/:id` | F-33–F-40 |
| `POST /tables` | F-26 |
| `PUT /tables/:id` | F-27 |
| `DELETE /tables/:id` | F-41 |
| `PATCH /tables/:id/status` | F-23, F-39 |
| `PATCH /tables/:id/online` | (future inline toggle) |
| `PATCH /tables/bulk-online` | F-16, F-46 |
| `POST /tables/:id/qr-code` | F-28, F-29, F-30 |
| `POST /tables/:id/images` | F-31 |
| `DELETE /tables/:id/images/:imgId` | F-32 |
| `GET /tables/stats` | F-01–F-05, F-07 |
| `GET /reservations/upcoming` | F-06 |

---

## 7. UI Component Dependencies

| Component | From | Used In |
|-----------|------|---------|
| `ALInput` | `@/components/ui/al-input` | `table-modal.tsx` |
| `ALCombobox` | `@/components/ui/al-combobox` | `table-modal.tsx`, `filter-bar.tsx` |
| `KeywordSearch` | `@/components/ui/keyword-search/keyword-search` | `filter-bar.tsx` |
| `Button` | `@/components/ui/button` | All components |
| `Card`, `CardContent`, `CardHeader`, `CardTitle`, `CardAction` | `@/components/ui/card` | `dashboard-summary.tsx`, `filter-bar.tsx`, `zone-section.tsx` |
| `Tabs`, `TabsList`, `TabsTrigger` | `@/components/ui/tabs` | `filter-bar.tsx` |
| `Dialog` | `@/components/ui/dialog` | `table-modal.tsx`, `delete-modal.tsx` |
| `Drawer`, `DrawerContent`, `DrawerHeader`, `DrawerTitle`, `DrawerDescription`, `DrawerFooter`, `DrawerClose` | `@/components/ui/drawer` | `table-detail-panel.tsx` |
| `Switch` | `@/components/ui/switch` | `table-modal.tsx` |
| `Badge` | `@/components/ui/badge` | `status-badge.tsx` |
| `FileUpload` + children | `@/components/ui/file-upload` | `table-modal.tsx` |
| `QRCodeCanvas` | `qrcode.react` | `table-modal.tsx` |
| Icons | `lucide-react` | All components |
| `Link` | `next/link` | `dashboard-summary.tsx` |
| `Image` | `next/image` | `table-card.tsx`, `table-detail-panel.tsx`, `delete-modal.tsx` |

---

## 8. Implementation Gaps (TODO)

| Priority | Gap | Details |
|----------|-----|---------|
| 🔴 High | **API service layer** | `services/` and `hooks/` directories are empty. Need `table.service.ts` with HTTP client calls + React Query hooks (`useTableList`, `useTableDetail`, `useTableMutation`, etc.). |
| 🔴 High | **Replace mock data** | `data.ts` mock used everywhere. Wire `GET /tables` to table-management orchestrator. |
| 🔴 High | **Replace mock reservations** | `MOCK_RESERVATIONS` in dashboard-summary.tsx → wire to `GET /reservations/upcoming`. |
| 🟡 Medium | **Form validation** | No Zod schemas or react-hook-form integration. Add `table.schemas.ts` with validation rules. |
| 🟡 Medium | **Delete guard** | `delete-modal.tsx` has no check for active orders or future reservations before deletion. |
| 🟡 Medium | **Server QR persistence** | QR generation is client-only (`qrcode.react`). Need `POST /tables/:id/qr-code` integration. |
| 🟡 Medium | **Server media upload** | Image upload creates blob URLs only. Need `POST /tables/:id/images` with multipart upload. |
| 🟢 Low | **Real-time updates** | No WebSocket integration. Table statuses don't auto-refresh. |
| 🟢 Low | **Detail panel: orders list** | Shows count only ("1 active order"). Need expandable list with order details. |
| 🟢 Low | **Detail panel: reservations** | No reservation list in detail panel. Need `GET /tables/:id/reservations`. |
| 🟢 Low | **Detail panel: error list** | Shows generic "has errors" message. Need specific error entries. |
| 🟢 Low | **Inline online toggle** | No per-table online/offline toggle on card or detail panel (only zone-level bulk toggle exists). |
| 🟢 Low | **Capacity range filter** | Filter bar lacks min/max capacity slider. |
