export { default } from "./table-management";
export { default as TableManagement } from "./table-management";
export type {
  TableManagementDto,
  TableDetailDto,
  TableMediaDto,
  UpcomingReservationDto,
  CreateTableRequest,
  UpdateTableRequest,
  UpdateTableStatusRequest,
  TableListParams,
  TableFilters,
  TableFormData,
  StatusConfig,
} from "./types";
export {
  ALLOWED_TRANSITIONS,
  canTransitionTo,
  TABLE_STATUS_CONFIG,
  TABLE_STATUS_CODES,
  TABLE_ZONE_ICONS,
} from "./types";
export * from "./components";
export * from "./hooks";
