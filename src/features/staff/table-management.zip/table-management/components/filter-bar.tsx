"use client";

import React from "react";
import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { ALCombobox } from "@/components/ui/al-combobox";
import { KeywordSearch } from "@/components/ui/keyword-search/keyword-search";
import { Card, CardContent } from "@/components/ui/card";
import type { TableFilters } from "../types";
import { TABLE_STATUS_CONFIG, TABLE_STATUS_CODES } from "../types";

interface FilterBarProps {
  filters: TableFilters;
  onFiltersChange: (filters: TableFilters) => void;
  /** Dynamic zone names derived from API data */
  zoneNames: string[];
  /** Dynamic type names derived from API data */
  typeNames: string[];
}

const STATUS_OPTIONS = [
  { label: "All Statuses", value: "ALL" },
  ...TABLE_STATUS_CODES.map((code) => ({
    label: TABLE_STATUS_CONFIG[code]?.label ?? code,
    value: code,
  })),
];

const ONLINE_OPTIONS = [
  { label: "All", value: "ALL" },
  { label: "Online", value: "ONLINE" },
  { label: "Offline", value: "OFFLINE" },
];

export const FilterBar: React.FC<FilterBarProps> = ({
  filters,
  onFiltersChange,
  zoneNames,
  typeNames,
}) => {
  const updateFilter = <K extends keyof TableFilters>(
    key: K,
    value: TableFilters[K]
  ) => {
    onFiltersChange({ ...filters, [key]: value });
  };

  // Build zone tabs dynamically from API data
  const zoneTabs = [
    { value: "ALL", label: "All Zones" },
    ...zoneNames.map((z) => ({ value: z, label: z })),
  ];

  // Build type options dynamically from API data
  const typeOptions = [
    { label: "All Types", value: "ALL" },
    ...typeNames.map((t) => ({ label: t, value: t })),
  ];

  return (
    <Card className="py-0 gap-0">
      <CardContent className="p-4 space-y-3">
        {/* Zone Tabs */}
        <Tabs
          value={filters.zone}
          onValueChange={(val) => updateFilter("zone", val)}
        >
          <TabsList variant="line">
            {zoneTabs.map((tab) => (
              <TabsTrigger key={tab.value} value={tab.value} className="text-sm">
                {tab.label}
              </TabsTrigger>
            ))}
          </TabsList>
        </Tabs>

        {/* Secondary filters row */}
        <div className="flex flex-wrap items-center gap-3">
          <KeywordSearch
            value={filters.search}
            placeholder="Search table code ..."
            onChange={(val) => updateFilter("search", val)}
            className="grow max-w-xs"
          />

          <ALCombobox
            options={typeOptions}
            value={filters.type}
            onChange={(val) => updateFilter("type", val as TableFilters["type"])}
            placeholder="Type"
            searchable={false}
            clearable
            inputSize="sm"
            wrapperClassName="w-40"
          />

          <ALCombobox
            options={STATUS_OPTIONS}
            value={filters.status}
            onChange={(val) => updateFilter("status", val as TableFilters["status"])}
            placeholder="Status"
            searchable={false}
            clearable
            inputSize="sm"
            wrapperClassName="w-44"
          />

          <ALCombobox
            options={ONLINE_OPTIONS}
            value={filters.isOnline}
            onChange={(val) => updateFilter("isOnline", val as TableFilters["isOnline"])}
            placeholder="Connection"
            searchable={false}
            clearable
            inputSize="sm"
            wrapperClassName="w-36"
          />
        </div>
      </CardContent>
    </Card>
  );
};

export default FilterBar;
