﻿"use client";

import React, { useState, useEffect, useCallback, useMemo, useRef } from "react";
import { QRCodeCanvas } from "qrcode.react";
import { Dialog } from "@/components/ui/dialog";
import { ALInput } from "@/components/ui/al-input";
import { ALCombobox } from "@/components/ui/al-combobox";
import { Button } from "@/components/ui/button";
import { Switch } from "@/components/ui/switch";
import {
  FileUpload,
  FileUploadDropzone,
  FileUploadList,
  FileUploadItem,
  FileUploadItemPreview,
  FileUploadItemMetadata,
  FileUploadItemDelete,
} from "@/components/ui/file-upload";
import { RefreshCcw, Download, Eye, Upload, Trash2, Loader2 } from "lucide-react";
import type { TableManagementDto, TableFormData } from "../types";
import { TABLE_STATUS_CONFIG } from "../types";

interface TableModalProps {
  isOpen: boolean;
  mode: "add" | "edit";
  table?: TableManagementDto | null;
  onClose: () => void;
  onSubmit: (data: TableFormData) => void;
  /** Disable submit while mutation is in-flight */
  isSubmitting?: boolean;
  /** All tables from API — used to derive unique dropdown options */
  tables: TableManagementDto[];
}

const initialFormData: TableFormData = {
  tableCode: "",
  capacity: 2,
  statusLvId: "",
  typeLvId: "",
  zoneLvId: "",
  isOnline: true,
};

const TableModal: React.FC<TableModalProps> = ({
  isOpen,
  mode,
  table,
  onClose,
  onSubmit,
  isSubmitting = false,
  tables,
}) => {
  const [formData, setFormData] = useState<TableFormData>(initialFormData);
  const [qrPreview, setQrPreview] = useState(false);
  const [uploadedFiles, setUploadedFiles] = useState<File[]>([]);
  const qrRef = useRef<HTMLDivElement>(null);

  // Derive unique lookup options from API data
  const statusOptions = useMemo(() => {
    const seen = new Map<number, string>();
    tables.forEach((t) => {
      if (!seen.has(t.statusId)) seen.set(t.statusId, TABLE_STATUS_CONFIG[t.statusCode]?.label ?? t.statusName);
    });
    // Ensure all known status codes are available even if not present in current data
    return Array.from(seen.entries()).map(([id, label]) => ({
      label,
      value: String(id),
    }));
  }, [tables]);

  const typeOptions = useMemo(() => {
    const seen = new Map<number, string>();
    tables.forEach((t) => {
      if (!seen.has(t.typeId)) seen.set(t.typeId, t.typeName);
    });
    return Array.from(seen.entries()).map(([id, label]) => ({
      label,
      value: String(id),
    }));
  }, [tables]);

  const zoneOptions = useMemo(() => {
    const seen = new Map<number, string>();
    tables.forEach((t) => {
      if (!seen.has(t.zoneId)) seen.set(t.zoneId, t.zoneName);
    });
    return Array.from(seen.entries()).map(([id, label]) => ({
      label,
      value: String(id),
    }));
  }, [tables]);

  useEffect(() => {
    if (mode === "edit" && table) {
      setFormData({
        tableCode: table.tableCode,
        capacity: table.capacity,
        statusLvId: table.statusId,
        typeLvId: table.typeId,
        zoneLvId: table.zoneId,
        isOnline: table.isOnline,
      });
    } else {
      setFormData(initialFormData);
      setQrPreview(false);
    }
    setUploadedFiles([]);
  }, [mode, table, isOpen]);

  const handleChange = (
    field: keyof TableFormData,
    value: string | number | boolean
  ) => {
    setFormData((prev) => ({ ...prev, [field]: value }));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onSubmit(formData);
  };

  // QR Code handlers
  const qrUrl = formData.tableCode
    ? `/order?table=${formData.tableCode}`
    : "";

  const handleGenerateQR = useCallback(() => {
    if (!formData.tableCode) return;
    setQrPreview(true);
  }, [formData.tableCode]);

  const handleDownloadQR = useCallback(() => {
    const canvas = qrRef.current?.querySelector("canvas");
    if (!canvas) return;
    const url = canvas.toDataURL("image/png");
    const link = document.createElement("a");
    link.download = `qr-${formData.tableCode || "table"}.png`;
    link.href = url;
    link.click();
  }, [formData.tableCode]);

  return (
    <Dialog
      open={isOpen}
      onClose={onClose}
      title={mode === "add" ? "Add New Table" : "Edit Table"}
      width="660px"
      footer={
        <div className="flex items-center gap-3 w-full">
          <Button
            type="button"
            variant="outline"
            className="w-full"
            onClick={onClose}
            disabled={isSubmitting}
          >
            Cancel
          </Button>
          <Button
            type="submit"
            form="table-form"
            variant="primary"
            className="w-full"
            disabled={isSubmitting}
          >
            {isSubmitting && <Loader2 size={14} className="mr-1.5 animate-spin" />}
            {mode === "add" ? "Add Table" : "Save Changes"}
          </Button>
        </div>
      }
    >
      <form id="table-form" onSubmit={handleSubmit}>
        <div className="space-y-5 p-5">
          {/* Table Code + Capacity row */}
          <div className="grid grid-cols-2 gap-4">
            <ALInput
              title="Table Code"
              required
              placeholder="e.g. T-01"
              value={formData.tableCode}
              onChange={(e) => handleChange("tableCode", e.target.value)}
            />
            <ALInput
              title="Capacity"
              required
              type="number"
              min={1}
              max={20}
              value={formData.capacity}
              onChange={(e) =>
                handleChange("capacity", parseInt(e.target.value) || 1)
              }
            />
          </div>

          {/* Zone + Type row */}
          <div className="grid grid-cols-2 gap-4">
            <ALCombobox
              title="Zone"
              required
              options={zoneOptions}
              value={formData.zoneLvId ? String(formData.zoneLvId) : undefined}
              onChange={(val) => handleChange("zoneLvId", val ? Number(val) : "")}
              placeholder="Select zone"
              searchable={false}
            />
            <ALCombobox
              title="Type"
              required
              options={typeOptions}
              value={formData.typeLvId ? String(formData.typeLvId) : undefined}
              onChange={(val) => handleChange("typeLvId", val ? Number(val) : "")}
              placeholder="Select type"
              searchable={false}
            />
          </div>

          {/* Status */}
          <ALCombobox
            title="Status"
            required
            options={statusOptions}
            value={formData.statusLvId ? String(formData.statusLvId) : undefined}
            onChange={(val) => handleChange("statusLvId", val ? Number(val) : "")}
            placeholder="Select status"
            searchable={false}
          />

          {/* Online toggle */}
          <div className="flex items-center justify-between bg-gray-50 rounded-lg p-3">
            <div>
              <p className="text-base font-medium text-gray-700">Online Status</p>
              <p className="text-xs text-gray-500">
                Table is visible to guests when online
              </p>
            </div>
            <Switch
              checked={formData.isOnline}
              onChange={(checked) => handleChange("isOnline", checked)}
            />
          </div>

          {/* QR Code Section */}
          <div className="space-y-3">
            <div className="flex items-center gap-2">
              <h5 className="text-sm font-semibold text-gray-500 uppercase tracking-wider">
                QR Code
              </h5>
              <div className="grow border-t border-gray-100" />
            </div>

            <div className="flex items-center gap-2">
              <Button
                type="button"
                variant="outline"
                size="sm"
                onClick={handleGenerateQR}
                disabled={!formData.tableCode}
              >
                <RefreshCcw size={13} className="mr-1" />
                Generate QR
              </Button>
              {qrPreview && (
                <>
                  <Button
                    type="button"
                    variant="outline"
                    size="sm"
                    onClick={handleDownloadQR}
                  >
                    <Download size={13} className="mr-1" />
                    Download
                  </Button>
                  <Button
                    type="button"
                    variant="ghost"
                    size="sm"
                    onClick={() => setQrPreview(false)}
                  >
                    <Eye size={13} className="mr-1" />
                    Hide
                  </Button>
                </>
              )}
            </div>

            {qrPreview && qrUrl && (
              <div className="bg-gray-50 rounded-lg p-4 flex items-start gap-4">
                <div ref={qrRef} className="shrink-0 bg-white rounded p-2">
                  <QRCodeCanvas value={qrUrl} size={96} level="M" />
                </div>
                <div className="space-y-1 min-w-0">
                  <p className="text-xs text-gray-500">
                    <span className="font-medium text-gray-600">Status:</span>{" "}
                    Generated
                  </p>
                  <p className="text-xs text-gray-500 break-all">
                    <span className="font-medium text-gray-600">URL:</span>{" "}
                    {qrUrl}
                  </p>
                </div>
              </div>
            )}

            {!qrPreview && (
              <p className="text-xs text-gray-400">
                Enter a table code and click Generate to create a QR code.
              </p>
            )}
          </div>

          {/* Media Section */}
          <div className="space-y-3">
            <div className="flex items-center gap-2">
              <h5 className="text-sm font-semibold text-gray-500 uppercase tracking-wider">
                Media
              </h5>
              <div className="grow border-t border-gray-100" />
            </div>

            {/* New file upload */}
            <FileUpload
              value={uploadedFiles}
              onValueChange={setUploadedFiles}
              accept="image/*"
              multiple
              maxFiles={5}
              maxSize={5 * 1024 * 1024}
            >
              <FileUploadDropzone className="min-h-0 gap-1.5 p-4">
                <div className="flex items-center gap-2 text-sm text-muted-foreground">
                  <Upload size={16} />
                  <span>Drop images here or click to upload</span>
                </div>
                <p className="text-xs text-muted-foreground/70">
                  PNG, JPG up to 5MB each (max 5 files)
                </p>
              </FileUploadDropzone>
              <FileUploadList className="mt-2">
                {uploadedFiles.map((file) => (
                  <FileUploadItem key={file.name + file.size} value={file}>
                    <div className="flex items-center gap-2">
                      <FileUploadItemPreview className="size-10 shrink-0" />
                      <FileUploadItemMetadata size="sm" className="flex-1" />
                      <FileUploadItemDelete asChild>
                        <Button
                          type="button"
                          variant="ghost"
                          size="icon"
                          className="size-7"
                        >
                          <Trash2 size={14} />
                        </Button>
                      </FileUploadItemDelete>
                    </div>
                  </FileUploadItem>
                ))}
              </FileUploadList>
            </FileUpload>
          </div>
        </div>
      </form>
    </Dialog>
  );
};

export default TableModal;
