"use client";

import React from "react";
import Image from "next/image";
import { cn } from "@/lib/utils";
import { Pencil, Trash2, QrCode, Loader2, CalendarClock, User, MapPin } from "lucide-react";
import { Button } from "@/components/ui/button";
import {
  Drawer,
  DrawerClose,
  DrawerContent,
  DrawerFooter,
  DrawerHeader,
  DrawerTitle,
  DrawerDescription,
} from "@/components/ui/drawer";
import type { TableManagementDto } from "../types";
import {
  TABLE_STATUS_CONFIG,
  TABLE_STATUS_CODES,
  canTransitionTo,
} from "../types";
import { useTableDetail } from "../hooks/use-table-detail";
import StatusBadge from "./status-badge";

interface TableDetailPanelProps {
  /** The ID of the table to display — detail is fetched internally */
  tableId: number | null;
  isOpen: boolean;
  onClose: () => void;
  /** Permission-gated: pass undefined to hide */
  onEdit?: (table: TableManagementDto) => void;
  /** Permission-gated: pass undefined to hide */
  onDelete?: (table: TableManagementDto) => void;
  /** Permission-gated: pass undefined to hide. Receives (tableId, statusCode) */
  onStatusChange?: (tableId: number, statusCode: string) => void;
}

export const TableDetailPanel: React.FC<TableDetailPanelProps> = ({
  tableId,
  isOpen,
  onClose,
  onEdit,
  onDelete,
  onStatusChange,
}) => {
  const { data: table, isLoading } = useTableDetail(tableId ?? 0);

  const config = table ? TABLE_STATUS_CONFIG[table.statusCode] : null;

  return (
    <Drawer open={isOpen} onOpenChange={(open) => !open && onClose()} direction="right">
      <DrawerContent className="h-full w-full max-w-md ml-auto rounded-none data-[vaul-drawer-direction=right]:sm:max-w-md">
        {/* Loading state */}
        {isLoading && (
          <div className="flex items-center justify-center flex-1 py-20">
            <Loader2 className="size-6 animate-spin text-gray-400" />
          </div>
        )}

        {!isLoading && !table && (
          <div className="flex items-center justify-center flex-1 py-20">
            <p className="text-sm text-gray-400">Table not found</p>
          </div>
        )}

        {table && config && (
          <>
            {/* Header */}
            <DrawerHeader className="border-b px-5 py-4">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <DrawerTitle className={cn("text-2xl font-bold", config.textColor)}>
                    {table.tableCode}
                  </DrawerTitle>
                  <span
                    className={cn(
                      "text-xs font-medium px-1.5 py-0.5 rounded",
                      table.isOnline
                        ? "bg-emerald-50 text-emerald-600"
                        : "bg-gray-100 text-gray-400"
                    )}
                  >
                    {table.isOnline ? "Online" : "Offline"}
                  </span>
                </div>
                <DrawerClose className="p-1.5 rounded-lg hover:bg-gray-100 transition-colors text-gray-400 hover:text-gray-600" />
              </div>
              <DrawerDescription className="sr-only">
                Details for table {table.tableCode}
              </DrawerDescription>
              <div className="mt-2">
                <StatusBadge statusCode={table.statusCode} size="md" />
              </div>
            </DrawerHeader>

            {/* Scrollable Content */}
            <div className="flex-1 overflow-y-auto p-5 space-y-6">
              {/* Table images from detail */}
              {table.images && table.images.length > 0 && (
                <div className="flex gap-2 overflow-x-auto">
                  {table.images.map((img) => (
                    <div
                      key={img.mediaId}
                      className="relative shrink-0 w-40 h-28 rounded-lg overflow-hidden bg-gray-50 border border-gray-100"
                    >
                      <Image
                        src={img.url}
                        alt={`Table ${table.tableCode}`}
                        fill
                        className="object-cover"
                        sizes="160px"
                      />
                      {img.isPrimary && (
                        <span className="absolute top-1 left-1 text-[10px] bg-black/50 text-white px-1.5 py-0.5 rounded">
                          Primary
                        </span>
                      )}
                    </div>
                  ))}
                </div>
              )}

              {/* Details section */}
              <div className="space-y-3">
                <h5 className="text-xs font-semibold text-gray-400 uppercase tracking-wider">
                  Details
                </h5>
                <div className="grid grid-cols-2 gap-4">
                  <InfoRow label="Zone" value={table.zoneName} />
                  <InfoRow label="Type" value={table.typeName} />
                  <InfoRow label="Capacity" value={`${table.capacity} seats`} />
                  <InfoRow
                    label="Connection"
                    value={table.isOnline ? "Online" : "Offline"}
                    valueClassName={
                      table.isOnline ? "text-emerald-600" : "text-gray-400"
                    }
                  />
                </div>
              </div>

              {/* Active Orders */}
              <div className="space-y-2">
                <h5 className="text-xs font-semibold text-gray-400 uppercase tracking-wider">
                  Active Orders
                </h5>
                {table.activeOrdersCount > 0 ? (
                  <div className="bg-amber-50 border border-amber-200 rounded-lg p-3 text-sm text-amber-700">
                    {table.activeOrdersCount} active order
                    {table.activeOrdersCount > 1 ? "s" : ""} on this table
                  </div>
                ) : (
                  <p className="text-sm text-gray-400">No active orders</p>
                )}
              </div>

              {/* Error info */}
              {table.hasErrors && (
                <div className="space-y-2">
                  <h5 className="text-xs font-semibold text-gray-400 uppercase tracking-wider">
                    Errors
                  </h5>
                  <div className="bg-red-50 border border-red-200 rounded-lg p-3 text-sm text-red-700">
                    This table has reported errors that need attention.
                  </div>
                </div>
              )}

              {/* QR Code */}
              {(table.qrCodeUrl || table.qrCodeImageUrl) && (
                <div className="space-y-2">
                  <h5 className="text-xs font-semibold text-gray-400 uppercase tracking-wider">
                    QR Code
                  </h5>
                  <div className="bg-gray-50 rounded-lg p-4 flex flex-col items-center gap-2">
                    {table.qrCodeImageUrl ? (
                      <Image
                        src={table.qrCodeImageUrl}
                        alt="QR Code"
                        width={96}
                        height={96}
                        className="rounded"
                      />
                    ) : (
                      <QrCode size={64} className="text-gray-600" />
                    )}
                    {table.qrCodeUrl && (
                      <span className="text-xs text-gray-400 break-all text-center">
                        {table.qrCodeUrl}
                      </span>
                    )}
                  </div>
                </div>
              )}

              {/* Upcoming Reservations */}
              {table.upcomingReservations && table.upcomingReservations.length > 0 && (
                <div className="space-y-2">
                  <h5 className="flex items-center gap-1.5 text-xs font-semibold text-gray-400 uppercase tracking-wider">
                    <CalendarClock size={13} />
                    Upcoming Reservations ({table.upcomingReservations.length})
                  </h5>
                  <div className="space-y-2">
                    {table.upcomingReservations.map((r) => (
                      <div
                        key={r.reservationId}
                        className="flex items-center gap-3 rounded-lg border border-gray-100 bg-white p-3"
                      >
                        <div className="flex-1 min-w-0">
                          <div className="flex items-center gap-1.5 mb-0.5">
                            <User size={12} className="text-gray-400 shrink-0" />
                            <p className="text-xs font-semibold text-gray-700 truncate">
                              {r.guestName}
                            </p>
                          </div>
                          <div className="flex items-center gap-1 text-[10px] text-gray-400">
                            <MapPin size={10} className="shrink-0" />
                            <span>{r.pax} pax</span>
                          </div>
                        </div>
                        <div className="text-right shrink-0">
                          <p className="text-xs font-bold text-gray-700">
                            {new Date(r.reservedTime).toLocaleTimeString([], {
                              hour: "2-digit",
                              minute: "2-digit",
                            })}
                          </p>
                          <span
                            className={cn(
                              "text-[10px] font-semibold px-2 py-0.5 rounded-full",
                              r.statusCode === "CONFIRMED"
                                ? "bg-emerald-50 text-emerald-700"
                                : "bg-gray-100 text-gray-500"
                            )}
                          >
                            {r.statusCode === "CONFIRMED" ? "Confirmed" : "Pending"}
                          </span>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* Quick status change — only show allowed transitions */}
              {onStatusChange && (
                <div className="space-y-2">
                  <h5 className="text-xs font-semibold text-gray-400 uppercase tracking-wider">
                    Quick Status Change
                  </h5>
                  <div className="flex flex-wrap gap-2">
                    {TABLE_STATUS_CODES.map((code) => {
                      const actionConf = TABLE_STATUS_CONFIG[code];
                      if (!actionConf) return null;
                      const isActive = table.statusCode === code;
                      const canTransition = canTransitionTo(table.statusCode, code);
                      if (!isActive && !canTransition) return null;

                      return (
                        <button
                          key={code}
                          disabled={isActive}
                          onClick={() =>
                            onStatusChange(table.tableId, code)
                          }
                          className={cn(
                            "text-xs px-3 py-1.5 rounded-full border transition-colors font-medium",
                            isActive
                              ? cn(
                                  actionConf.bgColor,
                                  actionConf.borderColor,
                                  actionConf.textColor,
                                  "cursor-default"
                                )
                              : "border-gray-200 text-gray-500 hover:border-gray-300 hover:bg-gray-50"
                          )}
                        >
                          <span
                            className={cn(
                              "inline-block w-1.5 h-1.5 rounded-full mr-1.5",
                              actionConf.dotColor
                            )}
                          />
                          {actionConf.label}
                        </button>
                      );
                    })}
                  </div>
                </div>
              )}
            </div>

            {/* Footer actions — only show buttons the user has permission for */}
            {(onEdit || onDelete) && (
              <DrawerFooter className="border-t bg-gray-50 flex-row gap-3">
                {onEdit && (
                  <Button
                    variant="outline"
                    className="flex-1"
                    onClick={() => onEdit(table)}
                  >
                    <Pencil size={14} className="mr-1.5" />
                    Edit
                  </Button>
                )}
                {onDelete && (
                  <Button
                    variant="danger"
                    className="flex-1"
                    onClick={() => onDelete(table)}
                  >
                    <Trash2 size={14} className="mr-1.5" />
                    Delete
                  </Button>
                )}
              </DrawerFooter>
            )}
          </>
        )}
      </DrawerContent>
    </Drawer>
  );
};

function InfoRow({
  label,
  value,
  valueClassName,
}: {
  label: string;
  value: React.ReactNode;
  valueClassName?: string;
}) {
  return (
    <div>
      <p className="text-[10px] font-medium text-gray-400 uppercase tracking-wide mb-0.5">
        {label}
      </p>
      <p className={cn("text-sm font-medium text-gray-700", valueClassName)}>
        {value}
      </p>
    </div>
  );
}

export default TableDetailPanel;
