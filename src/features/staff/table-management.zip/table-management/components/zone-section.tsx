"use client";

import React, { useMemo } from "react";
import { cn } from "@/lib/utils";
import {
  Card,
  CardContent,
  CardHeader,
  CardTitle,
  CardAction,
} from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import {
  ChevronDown,
  ChevronUp,
  Wifi,
  WifiOff,
  Users,
} from "lucide-react";
import type { TableManagementDto } from "../types";
import {
  TABLE_ZONE_ICONS,
  TABLE_STATUS_CONFIG,
} from "../types";
import TableCard from "./table-card";

interface ZoneSectionProps {
  zone: string;               // zoneName from API (e.g. "Indoor")
  tables: TableManagementDto[];
  collapsed?: boolean;
  onToggleCollapse?: (zone: string) => void;
  /** P1 — zone-level online/offline toggle (not yet wired to API) */
  onToggleZoneOnline?: (zone: string, online: boolean) => void;
  maxHeight?: number;
  onEdit?: (table: TableManagementDto) => void;
  onDelete?: (table: TableManagementDto) => void;
  onSelect?: (table: TableManagementDto) => void;
  onStatusChange?: (tableId: number, statusCode: string) => void;
}

const ZONE_SUBTITLES: Record<string, string> = {
  Indoor: "Main dining area",
  Outdoor: "Al fresco seating",
  Rooftop: "Upper-level terrace",
};

export const ZoneSection: React.FC<ZoneSectionProps> = ({
  zone,
  tables,
  collapsed = false,
  onToggleCollapse,
  onToggleZoneOnline,
  maxHeight = 520,
  onEdit,
  onDelete,
  onSelect,
  onStatusChange,
}) => {
  const stats = useMemo(() => {
    const available = tables.filter((t) => t.statusCode === "AVAILABLE").length;
    const occupied = tables.filter((t) => t.statusCode === "OCCUPIED").length;
    const reserved = tables.filter((t) => t.statusCode === "RESERVED").length;
    const online = tables.filter((t) => t.isOnline).length;
    const totalCapacity = tables.reduce((sum, t) => sum + t.capacity, 0);
    // activeOrders and errors are on TableDetailDto (not list DTO) — reserved for P1
    const activeOrders = 0;
    const errors = 0;
    return { available, occupied, reserved, online, totalCapacity, activeOrders, errors };
  }, [tables]);

  if (tables.length === 0) return null;

  const zoneIcon = TABLE_ZONE_ICONS[zone] ?? "📍";
  const allOnline = stats.online === tables.length;

  return (
    <Card className="py-0 gap-0">
      <CardHeader
        className={cn(
          "px-5 pt-4 pb-3 border-b border-gray-100 cursor-pointer select-none transition-colors hover:bg-gray-50/50",
          collapsed && "border-b-0"
        )}
        onClick={() => onToggleCollapse?.(zone)}
      >
        <div className="flex items-center gap-3 min-w-0">
          <div className="min-w-0">
            <CardTitle className="text-lg font-semibold text-gray-800 flex items-center gap-2">
              {zoneIcon} {zone}
              <span className="text-xs font-normal text-gray-400 bg-gray-100 rounded-full px-2 py-0.5">
                {tables.length}
              </span>
            </CardTitle>
            <p className="text-[11px] text-gray-400 mt-0.5">
              {ZONE_SUBTITLES[zone] ?? "Dining area"}
            </p>
          </div>
        </div>

        <CardAction>
          <div
            className="flex items-center gap-3"
            onClick={(e) => e.stopPropagation()}
          >
            {/* Zone stats pills */}
            <div className="hidden sm:flex items-center gap-2 text-[11px] text-gray-500">
              <span className="flex items-center gap-1">
                <span className={cn("w-1.5 h-1.5 rounded-full", TABLE_STATUS_CONFIG.AVAILABLE.dotColor)} />
                {stats.available} avail
              </span>
              <span className="text-gray-300">|</span>
              <span className="flex items-center gap-1">
                <Users size={11} />
                {stats.totalCapacity} seats
              </span>
              {stats.activeOrders > 0 && (
                <>
                  <span className="text-gray-300">|</span>
                  <span className="flex items-center gap-1 text-blue-600">
                    {stats.activeOrders} order{stats.activeOrders !== 1 ? "s" : ""}
                  </span>
                </>
              )}
              {stats.errors > 0 && (
                <>
                  <span className="text-gray-300">|</span>
                  <span className="flex items-center gap-1 text-orange-500">
                    {stats.errors} error{stats.errors !== 1 ? "s" : ""}
                  </span>
                </>
              )}
            </div>

            {/* Zone online/offline toggle — P1 */}
            {onToggleZoneOnline && (
              <Button
                variant="ghost"
                size="icon"
                className={cn(
                  "size-7",
                  allOnline ? "text-emerald-600" : "text-gray-400"
                )}
                title={allOnline ? "Set zone offline" : "Set zone online"}
                onClick={() => onToggleZoneOnline(zone, !allOnline)}
              >
                {allOnline ? <Wifi size={14} /> : <WifiOff size={14} />}
              </Button>
            )}

            {/* Collapse toggle */}
            <Button
              variant="ghost"
              size="icon"
              className="size-7 text-gray-400"
              onClick={() => onToggleCollapse?.(zone)}
            >
              {collapsed ? (
                <ChevronDown size={16} />
              ) : (
                <ChevronUp size={16} />
              )}
            </Button>
          </div>
        </CardAction>
      </CardHeader>

      {/* Collapsible content */}
      {!collapsed && (
        <CardContent className="p-5">
          {/* Inline mini status bar for zone */}
          <div className="flex items-center gap-3 mb-4">
            <div className="flex h-1.5 flex-1 rounded-full overflow-hidden bg-gray-100">
              {([
                { count: stats.available, color: TABLE_STATUS_CONFIG.AVAILABLE.dotColor },
                { count: stats.occupied, color: TABLE_STATUS_CONFIG.OCCUPIED.dotColor },
                { count: stats.reserved, color: TABLE_STATUS_CONFIG.RESERVED.dotColor },
              ] as const)
                .filter((seg) => seg.count > 0)
                .map((seg, idx) => (
                  <div
                    key={idx}
                    className={cn("h-full transition-all duration-300", seg.color)}
                    style={{ width: `${(seg.count / tables.length) * 100}%` }}
                  />
                ))}
            </div>
            <span className="text-[10px] text-gray-400 shrink-0 whitespace-nowrap">
              {stats.available}/{tables.length} available
            </span>
          </div>

          {/* Table grid with max height scroll */}
          <div
            className="overflow-y-auto pr-1 scrollbar-thin scrollbar-track-transparent scrollbar-thumb-gray-200 hover:scrollbar-thumb-gray-300"
            style={{ maxHeight: `${maxHeight}px` }}
          >
            <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 xl:grid-cols-6 gap-3">
              {tables.map((table) => (
                <TableCard
                  key={table.tableId}
                  table={table}
                  onEdit={onEdit}
                  onDelete={onDelete}
                  onSelect={onSelect}
                  onStatusChange={onStatusChange}
                />
              ))}
            </div>
          </div>
        </CardContent>
      )}
    </Card>
  );
};

export default ZoneSection;
