"use client";

import React, { useState, useMemo, useCallback } from "react";
import { CirclePlus, RefreshCcw, Loader2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { PermissionGuard } from "@/components/permission-guard";
import { usePermissions } from "@/hooks/use-permissions";
import { Permissions } from "@/types/const";
import type {
  TableManagementDto,
  TableFormData,
  TableFilters,
} from "./types";
import {
  DashboardSummary,
  FilterBar,
  ZoneSection,
  TableModal,
  DeleteModal,
  TableDetailPanel,
} from "./components";
import { useTables } from "./hooks/use-tables";
import {
  useCreateTable,
  useUpdateTable,
  useDeleteTable,
  useUpdateTableStatus,
} from "./hooks/use-table-mutations";
import type { CreateTableRequest, UpdateTableRequest, UpdateTableStatusRequest } from "./types";

const DEFAULT_FILTERS: TableFilters = {
  zone: "ALL",
  type: "ALL",
  status: "ALL",
  isOnline: "ALL",
  search: "",
};

const TableManagement: React.FC = () => {
  const { can } = usePermissions();
  const [filters, setFilters] = useState<TableFilters>(DEFAULT_FILTERS);

  // Fetch all tables (large page to get everything for the card grid)
  const {
    data: pagedResult,
    isLoading,
    refetch,
  } = useTables({ pageIndex: 1, pageSize: 200 });

  const tables = pagedResult?.pageData ?? [];

  // Mutations
  const createMutation = useCreateTable();
  const updateMutation = useUpdateTable();
  const deleteMutation = useDeleteTable();
  const statusMutation = useUpdateTableStatus();

  // Modal states
  const [isAddModalOpen, setIsAddModalOpen] = useState(false);
  const [isEditModalOpen, setIsEditModalOpen] = useState(false);
  const [isDeleteModalOpen, setIsDeleteModalOpen] = useState(false);
  const [selectedTable, setSelectedTable] = useState<TableManagementDto | null>(null);

  // Detail panel state
  const [detailTableId, setDetailTableId] = useState<number | null>(null);
  const [isDetailOpen, setIsDetailOpen] = useState(false);

  // Zone collapse state
  const [collapsedZones, setCollapsedZones] = useState<Set<string>>(new Set());

  // Apply client-side filters on the fetched data
  const filteredTables = useMemo(() => {
    return tables.filter((t) => {
      if (filters.zone !== "ALL" && t.zoneName !== filters.zone) return false;
      if (filters.type !== "ALL" && t.typeName !== filters.type) return false;
      if (filters.status !== "ALL" && t.statusCode !== filters.status) return false;
      if (filters.isOnline === "ONLINE" && !t.isOnline) return false;
      if (filters.isOnline === "OFFLINE" && t.isOnline) return false;
      if (
        filters.search.trim() &&
        !t.tableCode.toLowerCase().includes(filters.search.toLowerCase())
      )
        return false;
      return true;
    });
  }, [tables, filters]);

  // Derive unique zone names from data
  const zoneNames = useMemo(() => {
    const zones = new Set<string>();
    tables.forEach((t) => zones.add(t.zoneName));
    return Array.from(zones).sort();
  }, [tables]);

  // Derive unique type names from data
  const typeNames = useMemo(() => {
    const types = new Set<string>();
    tables.forEach((t) => types.add(t.typeName));
    return Array.from(types).sort();
  }, [tables]);

  // Group by zone for display
  const groupedByZone = useMemo(() => {
    const groups: Record<string, TableManagementDto[]> = {};
    filteredTables.forEach((t) => {
      if (!groups[t.zoneName]) groups[t.zoneName] = [];
      groups[t.zoneName].push(t);
    });
    return groups;
  }, [filteredTables]);

  // Show zone sections
  const zonesToShow = useMemo(() => {
    if (filters.zone !== "ALL") return [filters.zone];
    return zoneNames.filter((z) => (groupedByZone[z]?.length ?? 0) > 0);
  }, [filters.zone, zoneNames, groupedByZone]);

  // ── Handlers ──

  const handleAddTable = useCallback(
    (formData: TableFormData) => {
      if (!formData.statusLvId || !formData.typeLvId || !formData.zoneLvId) return;
      const req: CreateTableRequest = {
        tableCode: formData.tableCode,
        capacity: formData.capacity,
        isOnline: formData.isOnline,
        statusLvId: formData.statusLvId as number,
        typeLvId: formData.typeLvId as number,
        zoneLvId: formData.zoneLvId as number,
      };
      createMutation.mutate(req, {
        onSuccess: () => setIsAddModalOpen(false),
      });
    },
    [createMutation],
  );

  const handleEditTable = useCallback(
    (formData: TableFormData) => {
      if (!selectedTable) return;
      const req: UpdateTableRequest = {
        tableCode: formData.tableCode,
        capacity: formData.capacity,
        isOnline: formData.isOnline,
        ...(formData.statusLvId ? { statusLvId: formData.statusLvId as number } : {}),
        ...(formData.typeLvId ? { typeLvId: formData.typeLvId as number } : {}),
        ...(formData.zoneLvId ? { zoneLvId: formData.zoneLvId as number } : {}),
      };
      updateMutation.mutate(
        { id: selectedTable.tableId, data: req },
        {
          onSuccess: () => {
            setIsEditModalOpen(false);
            setSelectedTable(null);
          },
        },
      );
    },
    [selectedTable, updateMutation],
  );

  const handleDeleteTable = useCallback(() => {
    if (!selectedTable) return;
    deleteMutation.mutate(selectedTable.tableId, {
      onSuccess: () => {
        setIsDeleteModalOpen(false);
        setSelectedTable(null);
        if (detailTableId === selectedTable.tableId) {
          setIsDetailOpen(false);
          setDetailTableId(null);
        }
      },
    });
  }, [selectedTable, detailTableId, deleteMutation]);

  // Build a statusCode → statusLvId lookup from tables data
  const statusLookup = useMemo(() => {
    const map = new Map<string, number>();
    tables.forEach((t) => map.set(t.statusCode, t.statusId));
    return map;
  }, [tables]);

  const handleStatusChange = useCallback(
    (tableId: number, statusCode: string) => {
      const statusLvId = statusLookup.get(statusCode);
      if (!statusLvId) return;
      const req: UpdateTableStatusRequest = { statusLvId };
      statusMutation.mutate({ id: tableId, data: req });
    },
    [statusLookup, statusMutation],
  );

  const handleSelectTable = useCallback((table: TableManagementDto) => {
    setDetailTableId(table.tableId);
    setIsDetailOpen(true);
  }, []);

  const handleToggleZoneCollapse = useCallback((zone: string) => {
    setCollapsedZones((prev) => {
      const next = new Set(prev);
      if (next.has(zone)) next.delete(zone);
      else next.add(zone);
      return next;
    });
  }, []);

  const handleRefresh = useCallback(() => {
    setFilters(DEFAULT_FILTERS);
    setCollapsedZones(new Set());
    refetch();
  }, [refetch]);

  // Loading state
  if (isLoading) {
    return (
      <div className="flex items-center justify-center py-32">
        <Loader2 className="size-8 animate-spin text-gray-400" />
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Page Header */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center gap-3">
        <div className="grow">
          <h3 className="text-2xl font-bold text-gray-900 m-0">
            Table Management
          </h3>
          <p className="text-sm text-gray-400 mt-0.5">
            {filteredTables.length} table{filteredTables.length !== 1 ? "s" : ""}
            {filters.zone !== "ALL" && ` in ${filters.zone}`}
            {" "}&middot; {tables.filter((t) => t.statusCode === "AVAILABLE").length} available
          </p>
        </div>
        <div className="flex items-center gap-2">
          <Button variant="outline" size="sm" onClick={handleRefresh}>
            <RefreshCcw size={14} className="mr-1" />
            Refresh
          </Button>
          <PermissionGuard permission={Permissions.CreateTable}>
            <Button
              variant="primary"
              size="sm"
              onClick={() => setIsAddModalOpen(true)}
            >
              <CirclePlus size={14} className="mr-1" />
              Add Table
            </Button>
          </PermissionGuard>
        </div>
      </div>

      {/* Dashboard KPI Summary */}
      <DashboardSummary tables={tables} />

      {/* Filter bar */}
      <FilterBar
        filters={filters}
        onFiltersChange={setFilters}
        zoneNames={zoneNames}
        typeNames={typeNames}
      />

      {/* Zone Sections */}
      {zonesToShow.length > 0 ? (
        <div className="space-y-5">
          {zonesToShow.map((zone) => (
            <ZoneSection
              key={zone}
              zone={zone}
              tables={groupedByZone[zone] ?? []}
              collapsed={collapsedZones.has(zone)}
              onToggleCollapse={handleToggleZoneCollapse}
              onEdit={
                can(Permissions.EditTable)
                  ? (t) => {
                      setSelectedTable(t);
                      setIsEditModalOpen(true);
                    }
                  : undefined
              }
              onDelete={
                can(Permissions.DeleteTable)
                  ? (t) => {
                      setSelectedTable(t);
                      setIsDeleteModalOpen(true);
                    }
                  : undefined
              }
              onSelect={handleSelectTable}
              onStatusChange={
                can(Permissions.UpdateTableStatus) ? handleStatusChange : undefined
              }
            />
          ))}
        </div>
      ) : (
        <div className="flex flex-col items-center justify-center py-16 text-gray-400">
          <p className="text-base font-medium">No tables found</p>
          <p className="text-sm mt-1">Try adjusting your filters or add a new table.</p>
        </div>
      )}

      {/* Add Modal */}
      <TableModal
        isOpen={isAddModalOpen}
        mode="add"
        onClose={() => setIsAddModalOpen(false)}
        onSubmit={handleAddTable}
        isSubmitting={createMutation.isPending}
        tables={tables}
      />

      {/* Edit Modal */}
      <TableModal
        isOpen={isEditModalOpen}
        mode="edit"
        table={selectedTable}
        onClose={() => {
          setIsEditModalOpen(false);
          setSelectedTable(null);
        }}
        onSubmit={handleEditTable}
        isSubmitting={updateMutation.isPending}
        tables={tables}
      />

      {/* Delete Modal */}
      <DeleteModal
        isOpen={isDeleteModalOpen}
        table={selectedTable}
        onClose={() => {
          setIsDeleteModalOpen(false);
          setSelectedTable(null);
        }}
        onConfirm={handleDeleteTable}
        isDeleting={deleteMutation.isPending}
      />

      {/* Detail Panel */}
      <TableDetailPanel
        tableId={detailTableId}
        isOpen={isDetailOpen}
        onClose={() => {
          setIsDetailOpen(false);
          setDetailTableId(null);
        }}
        onEdit={
          can(Permissions.EditTable)
            ? (t) => {
                setSelectedTable(t);
                setIsEditModalOpen(true);
              }
            : undefined
        }
        onDelete={
          can(Permissions.DeleteTable)
            ? (t) => {
                setSelectedTable(t);
                setIsDeleteModalOpen(true);
              }
            : undefined
        }
        onStatusChange={
          can(Permissions.UpdateTableStatus) ? handleStatusChange : undefined
        }
      />
    </div>
  );
};

export default TableManagement;
